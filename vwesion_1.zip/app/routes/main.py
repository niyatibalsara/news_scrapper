# """
# main.py
# -------
# Publish flow (fixed):
#   1. Articles inserted into published_news  →  appear in Today's Published News immediately
#   2. Source rows DELETED from non_published_news  →  removed immediately (NOT after PDF)
#   3. Background thread generates PDFs one-by-one (Playwright visits real URL)
#   4. Background thread sends email once all PDFs are done

# PDF generation uses app.pdf_generator.generate_pdf_from_url (Playwright).
# Email + DB use raw mysql.connector — no Flask context needed in threads.
# Scraper uses raw mysql.connector — no Flask context needed.
# """

# from .auth import login_required
# from app.db import get_db

# import os
# import smtplib
# import threading
# import traceback
# from datetime import date, datetime
# from email import encoders
# from email.mime.base import MIMEBase
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText

# import mysql.connector
# from flask import (Blueprint, current_app, flash, jsonify,
#                    redirect, render_template, request,
#                    send_from_directory, url_for)

# main_bp = Blueprint("main", __name__)

# PER_PAGE = 10

# # ── Scraper state ─────────────────────────────────────────────
# _scraper_lock  = threading.Lock()
# _scraper_state = {"running": False, "message": "", "success": None}


# # ── Raw DB connection (safe in any thread, no Flask g) ────────
# def _raw_conn(db_cfg: dict):
#     return mysql.connector.connect(**db_cfg)


# # ── Extract DB config inside a request context ───────────────
# def _get_db_cfg() -> dict:
#     cfg = current_app.config
#     return {
#         "host":     cfg["MYSQL_HOST"],
#         "user":     cfg["MYSQL_USER"],
#         "password": cfg["MYSQL_PASSWORD"],
#         "database": cfg["MYSQL_DB"],
#     }


# # ================================================================
# #  Background: PDF generation + email
# #
# #  Called AFTER:
# #    - articles are already in published_news (visible to user)
# #    - source rows are already DELETED from non_published_news
# #
# #  This thread ONLY handles: PDF → update pdf_path → send email
# # ================================================================

# def _bg_pdf_email(db_cfg, mail_cfg, template_dir,
#                   articles, pub_ids, pdf_folder, settings):
#     """
#     Generate a PDF for each published article by visiting its real URL,
#     update pdf_path in DB, then send the email.

#     Parameters are all plain Python values — no Flask objects.
#     """
#     # Lazy import inside the thread to avoid import errors at app startup
#     try:
#         from app.pdf_generator import generate_pdf_from_url
#     except ImportError as e:
#         print(f"[BG] Cannot import pdf_generator: {e}")
#         generate_pdf_from_url = None

#     pdf_paths = []

#     for art, pub_id in zip(articles, pub_ids):
#         news_url  = (art.get("news_url") or "").strip()
#         safe_name = f"news_{pub_id}.pdf"
#         out_path  = os.path.join(pdf_folder, safe_name)
#         pdf_ok    = False

#         if not news_url:
#             print(f"[BG] pub_id={pub_id} has no URL — skipping PDF")
#         elif generate_pdf_from_url is None:
#             print(f"[BG] pdf_generator not available — skipping PDF for pub_id={pub_id}")
#         else:
#             try:
#                 pdf_ok = generate_pdf_from_url(url=news_url, output_path=out_path)
#             except Exception as e:
#                 print(f"[BG] PDF generation exception for pub_id={pub_id}: {e}")
#                 traceback.print_exc()

#         if pdf_ok:
#             try:
#                 c = _raw_conn(db_cfg)
#                 cur = c.cursor()
#                 cur.execute(
#                     "UPDATE published_news SET pdf_path=%s WHERE id=%s",
#                     (safe_name, pub_id)
#                 )
#                 c.commit()
#                 cur.close()
#                 c.close()
#                 print(f"[BG] PDF saved and DB updated: {safe_name}")
#             except Exception as e:
#                 print(f"[BG] DB update for pdf_path failed pub_id={pub_id}: {e}")
#             pdf_paths.append(out_path)
#         else:
#             print(f"[BG] PDF failed for pub_id={pub_id}, url={news_url}")
#             pdf_paths.append(None)

#     # ── Send email ───────────────────────────────────────────
#     if not settings.get("email_on_publish", 1):
#         print("[BG] email_on_publish=0 — skipping email.")
#         return

#     try:
#         _send_email_bg(
#             articles=articles,
#             pub_ids=pub_ids,
#             pdf_paths=pdf_paths,
#             settings=settings,
#             mail_cfg=mail_cfg,
#             template_dir=template_dir,
#         )
#     except Exception as e:
#         print(f"[BG] Email send failed: {e}")
#         traceback.print_exc()
#         return

#     # Mark email sent in DB
#     try:
#         c = _raw_conn(db_cfg)
#         cur = c.cursor()
#         for pid in pub_ids:
#             cur.execute(
#                 "UPDATE published_news SET email_sent=1, email_sent_at=NOW() WHERE id=%s",
#                 (pid,)
#             )
#         c.commit()
#         cur.close()
#         c.close()
#         print(f"[BG] email_sent marked for {len(pub_ids)} articles.")
#     except Exception as e:
#         print(f"[BG] Mark email_sent error: {e}")


# # ================================================================
# #  Email helpers (no Flask context — safe in any thread)
# # ================================================================

# def _render_email_template(template_dir: str, news_items: list, date_label: str) -> str:
#     from jinja2 import Environment, FileSystemLoader
#     env  = Environment(loader=FileSystemLoader(template_dir))
#     tmpl = env.get_template("email_template.html")
#     return tmpl.render(news_items=news_items, date_label=date_label)


# def _smtp_send(mail_cfg: dict, msg, recipients: list):
#     with smtplib.SMTP(mail_cfg["MAIL_SERVER"], mail_cfg["MAIL_PORT"]) as s:
#         s.ehlo()
#         if mail_cfg.get("MAIL_USE_TLS", True):
#             s.starttls()
#         s.login(mail_cfg["MAIL_USERNAME"], mail_cfg["MAIL_PASSWORD"])
#         s.sendmail(msg["From"], recipients, msg.as_string())
#         print(f"[EMAIL] Sent to: {recipients}")


# def _send_email_bg(articles, pub_ids, pdf_paths, settings, mail_cfg, template_dir):
#     to        = settings.get("email_recipient") or "niyati.b@seamlessautomations.com"
#     cc_raw    = settings.get("email_cc") or ""
#     cc        = [e.strip() for e in cc_raw.split(",") if e.strip()]
#     pfx       = settings.get("email_subject_prefix") or "Daily News Alert"
#     mode      = settings.get("publish_mode", "manual")
#     date_label = datetime.now().strftime("%d %B %Y")

#     if mode == "auto":
#         base  = mail_cfg.get("BASE_URL", "http://127.0.0.1:5000")
#         items = [
#             dict(a, pdf_view_url=f"{base}/download-pdf/{pid}")
#             for a, pid in zip(articles, pub_ids)
#         ]
#         html_body = _render_email_template(template_dir, items, date_label)
#     else:
#         html_body = _render_email_template(template_dir, list(articles), date_label)

#     msg            = MIMEMultipart("mixed")
#     msg["Subject"] = f"{pfx} — {date_label}"
#     msg["From"]    = mail_cfg.get("MAIL_FROM", mail_cfg.get("MAIL_USERNAME", ""))
#     msg["To"]      = to
#     if cc:
#         msg["Cc"]  = ", ".join(cc)

#     msg.attach(MIMEText(html_body, "html", "utf-8"))

#     # Attach PDFs in manual mode
#     if mode != "auto":
#         for p in pdf_paths:
#             if p and os.path.exists(p):
#                 with open(p, "rb") as f:
#                     part = MIMEBase("application", "octet-stream")
#                     part.set_payload(f.read())
#                 encoders.encode_base64(part)
#                 part.add_header(
#                     "Content-Disposition",
#                     f'attachment; filename="{os.path.basename(p)}"'
#                 )
#                 msg.attach(part)

#     _smtp_send(mail_cfg, msg, [to] + cc)


# # ================================================================
# #  Background scraper
# # ================================================================

# def _bg_scraper(db_cfg: dict, instance_path: str):
#     global _scraper_state
#     with _scraper_lock:
#         _scraper_state.update({"running": True, "message": "Scraper running…", "success": None})
#     try:
#         from app.news_scraper import run_news_scraper
#         result = run_news_scraper(db_config=db_cfg, instance_path=instance_path)
#         with _scraper_lock:
#             _scraper_state.update({
#                 "success": result.get("success", False),
#                 "message": result.get("message", "Scraper finished."),
#             })
#     except Exception as e:
#         with _scraper_lock:
#             _scraper_state.update({"success": False, "message": f"Scraper error: {e}"})
#         traceback.print_exc()
#     finally:
#         with _scraper_lock:
#             _scraper_state["running"] = False


# # ================================================================
# #  Routes
# # ================================================================

# @main_bp.route("/")
# def index():
#     return render_template("main/landing.html")


# @main_bp.route("/home")
# @login_required
# def home():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     today = date.today()
#     pub = unpub = 0
#     try:
#         cursor.execute(
#             "SELECT COUNT(*) AS cnt FROM published_news WHERE DATE(published_at)=%s",
#             (today,)
#         )
#         pub = cursor.fetchone()["cnt"]
#         cursor.execute(
#             "SELECT COUNT(*) AS cnt FROM non_published_news WHERE published=0"
#         )
#         unpub = cursor.fetchone()["cnt"]
#     except Exception as e:
#         print(f"[HOME] count error: {e}")
#     finally:
#         cursor.close()
#     return render_template(
#         "main/home.html",
#         today_published_count=pub,
#         today_unpublished_count=unpub,
#     )


# # ── Keywords ──────────────────────────────────────────────────
# @main_bp.route("/view-keywords", methods=["GET", "POST"])
# @login_required
# def view_keywords():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     if request.method == "POST":
#         action = request.form.get("action")
#         if action == "add":
#             sr_no = request.form.get("sr_no", "").strip()
#             kw    = request.form.get("keyword", "").strip()
#             if not sr_no or not kw:
#                 flash("Both Sr. No and Keyword are required.", "danger")
#             else:
#                 try:
#                     sr_no = int(sr_no)
#                     cursor.execute("SELECT id FROM keywords WHERE sr_no=%s", (sr_no,))
#                     if cursor.fetchone():
#                         flash("Sr. No already exists.", "danger")
#                     else:
#                         cursor.execute(
#                             "INSERT INTO keywords(sr_no,keyword) VALUES(%s,%s)",
#                             (sr_no, kw)
#                         )
#                         db.commit()
#                         flash("Keyword added.", "success")
#                 except ValueError:
#                     flash("Sr. No must be a number.", "danger")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_keywords"))
#         elif action == "edit":
#             kid = request.form.get("keyword_id", "").strip()
#             kw  = request.form.get("edit_keyword", "").strip()
#             if not kid or not kw:
#                 flash("Keyword ID and value required.", "danger")
#             else:
#                 try:
#                     cursor.execute("UPDATE keywords SET keyword=%s WHERE id=%s", (kw, kid))
#                     db.commit()
#                     flash("Updated." if cursor.rowcount else "Not found.",
#                           "success" if cursor.rowcount else "warning")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_keywords"))
#         elif action == "bulk_delete":
#             ids = request.form.getlist("selected_keywords")
#             if not ids:
#                 flash("Select at least one.", "warning")
#             else:
#                 try:
#                     ph = ",".join(["%s"] * len(ids))
#                     cursor.execute(f"DELETE FROM keywords WHERE id IN ({ph})", tuple(ids))
#                     db.commit()
#                     flash("Deleted.", "success")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_keywords"))
#     cursor.execute("SELECT id,sr_no,keyword FROM keywords ORDER BY sr_no ASC")
#     keywords = cursor.fetchall()
#     cursor.close()
#     return render_template("main/view_keywords.html", keywords=keywords)


# # ── Websites ───────────────────────────────────────────────────
# @main_bp.route("/view-websites", methods=["GET", "POST"])
# @login_required
# def view_websites():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     if request.method == "POST":
#         action = request.form.get("action")
#         if action == "add":
#             sr_no = request.form.get("sr_no", "").strip()
#             val   = request.form.get("websites", "").strip()
#             if not sr_no or not val:
#                 flash("Both fields required.", "danger")
#             else:
#                 try:
#                     sr_no = int(sr_no)
#                     cursor.execute("SELECT id FROM websites WHERE sr_no=%s", (sr_no,))
#                     if cursor.fetchone():
#                         flash("Sr. No exists.", "danger")
#                     else:
#                         cursor.execute(
#                             "INSERT INTO websites(sr_no,websites) VALUES(%s,%s)",
#                             (sr_no, val)
#                         )
#                         db.commit()
#                         flash("Website added.", "success")
#                 except ValueError:
#                     flash("Sr. No must be a number.", "danger")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_websites"))
#         elif action == "edit":
#             wid = request.form.get("websites_id", "").strip()
#             val = request.form.get("edit_websites", "").strip()
#             if not wid or not val:
#                 flash("Both fields required.", "danger")
#             else:
#                 try:
#                     cursor.execute("UPDATE websites SET websites=%s WHERE id=%s", (val, wid))
#                     db.commit()
#                     flash("Updated." if cursor.rowcount else "Not found.",
#                           "success" if cursor.rowcount else "warning")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_websites"))
#         elif action == "bulk_delete":
#             ids = request.form.getlist("selected_websites")
#             if not ids:
#                 flash("Select at least one.", "warning")
#             else:
#                 try:
#                     ph = ",".join(["%s"] * len(ids))
#                     cursor.execute(f"DELETE FROM websites WHERE id IN ({ph})", tuple(ids))
#                     db.commit()
#                     flash("Deleted.", "success")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_websites"))
#     cursor.execute("SELECT id,sr_no,websites FROM websites ORDER BY sr_no ASC")
#     websites = cursor.fetchall()
#     cursor.close()
#     return render_template("main/view_websites.html", websites=websites)


# # ── News Type ──────────────────────────────────────────────────
# @main_bp.route("/view-news-type", methods=["GET", "POST"])
# @login_required
# def view_news_type():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     if request.method == "POST":
#         action = request.form.get("action")
#         if action == "add":
#             sr_no = request.form.get("sr_no", "").strip()
#             val   = request.form.get("news_type", "").strip()
#             if not sr_no or not val:
#                 flash("Both fields required.", "danger")
#             else:
#                 try:
#                     sr_no = int(sr_no)
#                     cursor.execute("SELECT id FROM news WHERE sr_no=%s", (sr_no,))
#                     if cursor.fetchone():
#                         flash("Sr. No exists.", "danger")
#                     else:
#                         cursor.execute(
#                             "INSERT INTO news(sr_no,news_type) VALUES(%s,%s)",
#                             (sr_no, val)
#                         )
#                         db.commit()
#                         flash("News type added.", "success")
#                 except ValueError:
#                     flash("Sr. No must be a number.", "danger")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_news_type"))
#         elif action == "edit":
#             ntid = request.form.get("news_type_id", "").strip()
#             val  = request.form.get("edit_news_type", "").strip()
#             if not ntid or not val:
#                 flash("Both fields required.", "danger")
#             else:
#                 try:
#                     cursor.execute("UPDATE news SET news_type=%s WHERE id=%s", (val, ntid))
#                     db.commit()
#                     flash("Updated." if cursor.rowcount else "Not found.",
#                           "success" if cursor.rowcount else "warning")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_news_type"))
#         elif action == "bulk_delete":
#             ids = request.form.getlist("selected_news_types")
#             if not ids:
#                 flash("Select at least one.", "warning")
#             else:
#                 try:
#                     ph = ",".join(["%s"] * len(ids))
#                     cursor.execute(f"DELETE FROM news WHERE id IN ({ph})", tuple(ids))
#                     db.commit()
#                     flash("Deleted.", "success")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_news_type"))
#     cursor.execute("SELECT id,sr_no,news_type FROM news ORDER BY sr_no ASC")
#     news_types = cursor.fetchall()
#     cursor.close()
#     return render_template("main/view_news_type.html", news_types=news_types)


# # ── Commodity ──────────────────────────────────────────────────
# @main_bp.route("/view-commodity", methods=["GET", "POST"])
# @login_required
# def view_commodity():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     if request.method == "POST":
#         action = request.form.get("action")
#         if action == "add":
#             sr_no = request.form.get("sr_no", "").strip()
#             val   = request.form.get("commodity", "").strip()
#             if not sr_no or not val:
#                 flash("Both fields required.", "danger")
#             else:
#                 try:
#                     sr_no = int(sr_no)
#                     cursor.execute("SELECT id FROM commodity WHERE sr_no=%s", (sr_no,))
#                     if cursor.fetchone():
#                         flash("Sr. No exists.", "danger")
#                     else:
#                         cursor.execute(
#                             "INSERT INTO commodity(sr_no,commodity) VALUES(%s,%s)",
#                             (sr_no, val)
#                         )
#                         db.commit()
#                         flash("Commodity added.", "success")
#                 except ValueError:
#                     flash("Sr. No must be a number.", "danger")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_commodity"))
#         elif action == "edit":
#             cid = request.form.get("commodity_id", "").strip()
#             val = request.form.get("edit_commodity", "").strip()
#             if not cid or not val:
#                 flash("Both fields required.", "danger")
#             else:
#                 try:
#                     cursor.execute("UPDATE commodity SET commodity=%s WHERE id=%s", (val, cid))
#                     db.commit()
#                     flash("Updated." if cursor.rowcount else "Not found.",
#                           "success" if cursor.rowcount else "warning")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_commodity"))
#         elif action == "bulk_delete":
#             ids = request.form.getlist("selected_commodities")
#             if not ids:
#                 flash("Select at least one.", "warning")
#             else:
#                 try:
#                     ph = ",".join(["%s"] * len(ids))
#                     cursor.execute(f"DELETE FROM commodity WHERE id IN ({ph})", tuple(ids))
#                     db.commit()
#                     flash("Deleted.", "success")
#                 except Exception as e:
#                     db.rollback()
#                     flash(f"Error: {e}", "danger")
#             cursor.close()
#             return redirect(url_for("main.view_commodity"))
#     cursor.execute("SELECT id,sr_no,commodity FROM commodity ORDER BY sr_no ASC")
#     commodities = cursor.fetchall()
#     cursor.close()
#     return render_template("main/view_commodity.html", commodities=commodities)


# # ================================================================
# #  All Non-Published News — GET (paginated)
# # ================================================================

# @main_bp.route("/all-non-published-news")
# @login_required
# def all_non_published_news():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     try:
#         cursor.execute("SELECT * FROM user_settings WHERE id=1")
#         settings = cursor.fetchone() or {}
#     except Exception:
#         settings = {}

#     cats_str = settings.get("content_categories", "all") or "all"
#     cats     = [c.strip().lower() for c in cats_str.split(",") if c.strip()]
#     page     = max(1, int(request.args.get("page", 1)))

#     try:
#         if "all" in cats:
#             cursor.execute(
#                 "SELECT COUNT(*) AS cnt FROM non_published_news WHERE published=0"
#             )
#         else:
#             ph = ",".join(["%s"] * len(cats))
#             cursor.execute(
#                 f"SELECT COUNT(*) AS cnt FROM non_published_news "
#                 f"WHERE published=0 AND LOWER(news_type) IN ({ph})",
#                 tuple(cats)
#             )
#         total = cursor.fetchone()["cnt"]
#         total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
#         page   = min(page, total_pages)
#         offset = (page - 1) * PER_PAGE

#         if "all" in cats:
#             cursor.execute(
#                 "SELECT id,news_date,news_type,news_headline,"
#                 "news_text,news_url,keywords,date_of_insert "
#                 "FROM non_published_news WHERE published=0 "
#                 "ORDER BY date_of_insert DESC LIMIT %s OFFSET %s",
#                 (PER_PAGE, offset)
#             )
#         else:
#             ph = ",".join(["%s"] * len(cats))
#             cursor.execute(
#                 f"SELECT id,news_date,news_type,news_headline,"
#                 f"news_text,news_url,keywords,date_of_insert "
#                 f"FROM non_published_news WHERE published=0 "
#                 f"AND LOWER(news_type) IN ({ph}) "
#                 f"ORDER BY date_of_insert DESC LIMIT %s OFFSET %s",
#                 tuple(cats) + (PER_PAGE, offset)
#             )
#         news = cursor.fetchall()

#     except Exception as e:
#         flash(f"Error loading news: {e}", "danger")
#         news, total, total_pages, page = [], 0, 1, 1
#     finally:
#         cursor.close()

#     with _scraper_lock:
#         scrape_running = _scraper_state["running"]

#     return render_template(
#         "main/all_non_published_news.html",
#         news=news,
#         scrape_running=scrape_running,
#         page=page,
#         total_pages=total_pages,
#         total=total,
#         per_page=PER_PAGE,
#     )


# # ================================================================
# #  All Non-Published News — POST (publish / delete)
# # ================================================================

# @main_bp.route("/all-non-published-news/actions", methods=["POST"])
# @login_required
# def all_non_published_news_actions():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     action = request.form.get("action")
#     ids    = request.form.getlist("selected_news")

#     if not ids:
#         flash("Please select at least one article.", "warning")
#         cursor.close()
#         return redirect(url_for("main.all_non_published_news"))

#     ph = ",".join(["%s"] * len(ids))

#     try:
#         # ── DELETE ───────────────────────────────────────────────
#         if action == "delete":
#             cursor.execute(
#                 f"DELETE FROM non_published_news WHERE id IN ({ph})",
#                 tuple(ids)
#             )
#             db.commit()
#             flash(f"{cursor.rowcount} article(s) deleted.", "success")

#         # ── PUBLISH ──────────────────────────────────────────────
#         elif action == "publish":
#             # Fetch selected articles
#             cursor.execute(
#                 f"SELECT id, news_date, news_type, news_headline, "
#                 f"news_text, news_url, keywords, date_of_insert "
#                 f"FROM non_published_news WHERE id IN ({ph})",
#                 tuple(ids)
#             )
#             articles = cursor.fetchall()

#             if not articles:
#                 flash("No articles found for selected IDs.", "warning")
#                 cursor.close()
#                 return redirect(url_for("main.all_non_published_news"))

#             # Load settings
#             try:
#                 cursor.execute("SELECT * FROM user_settings WHERE id=1")
#                 settings = cursor.fetchone() or {}
#             except Exception:
#                 settings = {}

#             # Ensure PDF output folder exists
#             pdf_folder = current_app.config.get(
#                 "PDF_FOLDER",
#                 os.path.join(current_app.root_path, "static", "pdfs")
#             )
#             os.makedirs(pdf_folder, exist_ok=True)

#             now     = datetime.now()
#             pub_ids = []

#             # STEP 1: Insert ALL articles into published_news immediately
#             # They will appear in Today's Published News right away.
#             for art in articles:
#                 cursor.execute(
#                     "INSERT INTO published_news "
#                     "(source_id, news_date, news_type, news_headline, "
#                     "news_text, news_url, keywords, date_of_insert, published_at) "
#                     "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
#                     (
#                         art["id"],
#                         art["news_date"],
#                         art["news_type"],
#                         art["news_headline"],
#                         art["news_text"],
#                         art["news_url"],
#                         art["keywords"],
#                         art["date_of_insert"],
#                         now,
#                     )
#                 )
#                 db.commit()
#                 pub_ids.append(cursor.lastrowid)

#             # STEP 2: Delete source rows from non_published_news IMMEDIATELY
#             # (NOT after PDF generation — this is the fix for articles
#             #  staying in the non-published list)
#             cursor.execute(
#                 f"DELETE FROM non_published_news WHERE id IN ({ph})",
#                 tuple(ids)
#             )
#             db.commit()
#             print(f"[PUBLISH] Deleted {len(ids)} rows from non_published_news.")

#             # STEP 3: Collect all values needed BEFORE leaving request context
#             db_cfg = _get_db_cfg()
#             cfg    = current_app.config
#             mail_cfg = {
#                 "MAIL_SERVER":   cfg.get("MAIL_SERVER",   "smtp.gmail.com"),
#                 "MAIL_PORT":     cfg.get("MAIL_PORT",     587),
#                 "MAIL_USE_TLS":  cfg.get("MAIL_USE_TLS",  True),
#                 "MAIL_USERNAME": cfg.get("MAIL_USERNAME", ""),
#                 "MAIL_PASSWORD": cfg.get("MAIL_PASSWORD", ""),
#                 "MAIL_FROM":     cfg.get("MAIL_FROM",     cfg.get("MAIL_USERNAME", "")),
#                 "BASE_URL":      cfg.get("BASE_URL",      "http://127.0.0.1:5000"),
#             }
#             template_dir = os.path.join(current_app.root_path, "templates", "main")

#             # STEP 4: PDF generation + email in background thread
#             # Pass only plain Python values — no Flask objects
#             threading.Thread(
#                 target=_bg_pdf_email,
#                 args=(
#                     db_cfg,
#                     mail_cfg,
#                     template_dir,
#                     list(articles),   # plain list of dicts
#                     list(pub_ids),    # plain list of ints
#                     pdf_folder,       # plain string
#                     dict(settings),   # plain dict
#                 ),
#                 daemon=True,
#             ).start()

#             flash(
#                 f"{len(articles)} article(s) published successfully! "
#                 f"They are now visible in Today's Published News. "
#                 f"PDFs are being generated from the original news websites in the background.",
#                 "success",
#             )

#     except Exception as e:
#         db.rollback()
#         flash(f"Error during publish: {e}", "danger")
#         traceback.print_exc()
#     finally:
#         cursor.close()

#     return redirect(url_for("main.all_non_published_news"))


# # ================================================================
# #  Refresh News — background scraper
# # ================================================================

# @main_bp.route("/refresh-news", methods=["POST"])
# @login_required
# def refresh_news():
#     with _scraper_lock:
#         if _scraper_state["running"]:
#             flash("Scraper is already running.", "warning")
#             return redirect(url_for("main.all_non_published_news"))

#     # Extract plain values INSIDE request context, then pass to thread
#     db_cfg        = _get_db_cfg()
#     instance_path = current_app.instance_path

#     threading.Thread(
#         target=_bg_scraper,
#         args=(db_cfg, instance_path),
#         daemon=True,
#     ).start()

#     flash("News refresh started in the background. Page will auto-update when complete.", "info")
#     return redirect(url_for("main.all_non_published_news"))


# @main_bp.route("/refresh-news/status")
# @login_required
# def refresh_news_status():
#     with _scraper_lock:
#         state = dict(_scraper_state)
#     return jsonify(state)


# # ================================================================
# #  Today's Published News — paginated
# # ================================================================

# @main_bp.route("/today-published-news")
# @login_required
# def today_published_news():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     today = date.today()
#     page  = max(1, int(request.args.get("page", 1)))

#     try:
#         cursor.execute(
#             "SELECT COUNT(*) AS cnt FROM published_news WHERE DATE(published_at)=%s",
#             (today,)
#         )
#         total = cursor.fetchone()["cnt"]
#         total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
#         page   = min(page, total_pages)
#         offset = (page - 1) * PER_PAGE

#         cursor.execute(
#             "SELECT id, news_date, news_type, news_headline, "
#             "news_url, pdf_path, published_at "
#             "FROM published_news WHERE DATE(published_at)=%s "
#             "ORDER BY published_at DESC LIMIT %s OFFSET %s",
#             (today, PER_PAGE, offset)
#         )
#         news = cursor.fetchall()

#     except Exception as e:
#         flash(f"Error loading published news: {e}", "danger")
#         news, total, total_pages, page = [], 0, 1, 1
#     finally:
#         cursor.close()

#     return render_template(
#         "main/today_published_news.html",
#         news=news,
#         today=today,
#         page=page,
#         total_pages=total_pages,
#         total=total,
#         per_page=PER_PAGE,
#     )


# # ================================================================
# #  Check PDF ready — polled by JS every 8 s
# # ================================================================

# @main_bp.route("/check-pdf/<int:news_id>")
# @login_required
# def check_pdf_ready(news_id):
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     try:
#         cursor.execute(
#             "SELECT pdf_path FROM published_news WHERE id=%s",
#             (news_id,)
#         )
#         row = cursor.fetchone()
#     finally:
#         cursor.close()

#     ready = False
#     if row and row.get("pdf_path"):
#         pdf_folder = current_app.config.get(
#             "PDF_FOLDER",
#             os.path.join(current_app.root_path, "static", "pdfs")
#         )
#         fp    = os.path.join(pdf_folder, row["pdf_path"])
#         ready = os.path.exists(fp) and os.path.getsize(fp) > 500

#     return jsonify({"ready": ready})


# # ================================================================
# #  Download PDF
# # ================================================================

# @main_bp.route("/download-pdf/<int:news_id>")
# @login_required
# def download_pdf(news_id):
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     try:
#         cursor.execute(
#             "SELECT pdf_path FROM published_news WHERE id=%s",
#             (news_id,)
#         )
#         row = cursor.fetchone()
#     finally:
#         cursor.close()

#     if not row or not row["pdf_path"]:
#         flash("PDF is still being generated — please try again in a moment.", "warning")
#         return redirect(url_for("main.today_published_news"))

#     pdf_folder = current_app.config.get(
#         "PDF_FOLDER",
#         os.path.join(current_app.root_path, "static", "pdfs")
#     )
#     return send_from_directory(pdf_folder, row["pdf_path"], as_attachment=True)


# # ================================================================
# #  Manual re-send email for today
# # ================================================================

# @main_bp.route("/send-email-today")
# @login_required
# def send_email_today():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     today  = date.today()

#     try:
#         cursor.execute(
#             "SELECT id, news_date, news_type, news_headline, news_url, pdf_path "
#             "FROM published_news WHERE DATE(published_at)=%s "
#             "ORDER BY published_at DESC",
#             (today,)
#         )
#         articles = cursor.fetchall()

#         if not articles:
#             flash("No published news for today.", "warning")
#             cursor.close()
#             return redirect(url_for("main.today_published_news"))

#         try:
#             cursor.execute("SELECT * FROM user_settings WHERE id=1")
#             settings = cursor.fetchone() or {}
#         except Exception:
#             settings = {}

#         cfg = current_app.config
#         mail_cfg = {
#             "MAIL_SERVER":   cfg.get("MAIL_SERVER",   "smtp.gmail.com"),
#             "MAIL_PORT":     cfg.get("MAIL_PORT",     587),
#             "MAIL_USE_TLS":  cfg.get("MAIL_USE_TLS",  True),
#             "MAIL_USERNAME": cfg.get("MAIL_USERNAME", ""),
#             "MAIL_PASSWORD": cfg.get("MAIL_PASSWORD", ""),
#             "MAIL_FROM":     cfg.get("MAIL_FROM",     cfg.get("MAIL_USERNAME", "")),
#             "BASE_URL":      cfg.get("BASE_URL",      "http://127.0.0.1:5000"),
#         }
#         pdf_folder   = cfg.get("PDF_FOLDER", os.path.join(current_app.root_path, "static", "pdfs"))
#         template_dir = os.path.join(current_app.root_path, "templates", "main")
#         pdf_paths    = [
#             os.path.join(pdf_folder, a["pdf_path"])
#             for a in articles if a.get("pdf_path")
#         ]
#         pub_ids = [a["id"] for a in articles]

#         _send_email_bg(
#             articles=list(articles),
#             pub_ids=pub_ids,
#             pdf_paths=pdf_paths,
#             settings=dict(settings),
#             mail_cfg=mail_cfg,
#             template_dir=template_dir,
#         )
#         flash("Email sent successfully.", "success")

#     except Exception as e:
#         flash(f"Failed to send email: {e}", "danger")
#         traceback.print_exc()
#     finally:
#         cursor.close()

#     return redirect(url_for("main.today_published_news"))


# # ================================================================
# #  User Settings
# # ================================================================

# @main_bp.route("/user-settings", methods=["GET", "POST"])
# @login_required
# def user_settings():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == "POST":
#         try:
#             cursor.execute(
#                 "INSERT INTO user_settings "
#                 "(id, run_frequency, custom_frequency, scraper_enabled, "
#                 "publish_mode, content_categories, email_recipient, "
#                 "email_cc, email_subject_prefix, email_on_publish) "
#                 "VALUES (1,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
#                 "ON DUPLICATE KEY UPDATE "
#                 "run_frequency=VALUES(run_frequency), "
#                 "custom_frequency=VALUES(custom_frequency), "
#                 "scraper_enabled=VALUES(scraper_enabled), "
#                 "publish_mode=VALUES(publish_mode), "
#                 "content_categories=VALUES(content_categories), "
#                 "email_recipient=VALUES(email_recipient), "
#                 "email_cc=VALUES(email_cc), "
#                 "email_subject_prefix=VALUES(email_subject_prefix), "
#                 "email_on_publish=VALUES(email_on_publish)",
#                 (
#                     request.form.get("run_frequency", "1"),
#                     request.form.get("custom_frequency") or None,
#                     1 if request.form.get("scraper_enabled") else 0,
#                     request.form.get("publish_mode", "manual"),
#                     ",".join(request.form.getlist("content_categories")) or "all",
#                     request.form.get("email_recipient", "").strip(),
#                     request.form.get("email_cc", "").strip(),
#                     request.form.get("email_subject_prefix", "Daily News Alert").strip(),
#                     1 if request.form.get("email_on_publish") else 0,
#                 )
#             )
#             db.commit()
#             flash("Settings saved.", "success")
#         except Exception as e:
#             db.rollback()
#             flash(f"Error: {e}", "danger")
#         finally:
#             cursor.close()
#         return redirect(url_for("main.user_settings"))

#     try:
#         cursor.execute("SELECT * FROM user_settings WHERE id=1")
#         settings = cursor.fetchone() or {}
#     except Exception:
#         settings = {}
#     finally:
#         cursor.close()

#     return render_template("main/user_settings.html", settings=settings)


# def get_settings():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     try:
#         cursor.execute("SELECT * FROM user_settings WHERE id=1")
#         return cursor.fetchone() or {}
#     except Exception:
#         return {}
#     finally:
#         cursor.close()

"""
main.py
-------
Updated publish flow:
  1. Articles inserted into published_news immediately
  2. Source rows deleted from non_published_news immediately
  3. Background thread generates PDFs from the ORIGINAL news URL
  4. DB updated with pdf_path only after successful PDF creation
  5. Email is sent after PDF processing completes

This version adds:
  - stronger logging
  - URL validation logs
  - PDF folder creation safety
  - retry-friendly PDF flow
  - non-daemon background thread for safer execution
"""

from .auth import login_required
from app.db import get_db

import os
import json
import requests
import smtplib
import threading
import traceback
from datetime import date, datetime
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import mysql.connector
from flask import (
    Blueprint,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)

main_bp = Blueprint("main", __name__)

PER_PAGE = 10

# ── Scraper state ─────────────────────────────────────────────
_scraper_lock = threading.Lock()
_scraper_state = {"running": False, "message": "", "success": None}


# ── Raw DB connection (safe in any thread, no Flask g) ────────
def _raw_conn(db_cfg: dict):
    return mysql.connector.connect(**db_cfg)


# ── Extract DB config inside a request context ───────────────
def _get_db_cfg() -> dict:
    cfg = current_app.config
    return {
        "host": cfg["MYSQL_HOST"],
        "user": cfg["MYSQL_USER"],
        "password": cfg["MYSQL_PASSWORD"],
        "database": cfg["MYSQL_DB"],
    }

def get_weather_overview(temp, humidity, wind, desc):
    """Generates a structured overview for farmers."""
    # Logic for specific warnings
    wind_status = "Breezy" if wind > 5.0 else "Calm"
    precip_status = "Rain likely" if 'rain' in desc.lower() else "Dry"
    
    overview = (
        f"* ADVISORY: {desc.upper()} in effect.\n"
        f"* WHAT: Temp {temp}°C with {humidity}% humidity.\n"
        f"* WIND: {wind_status} ({wind} m/s).\n"
        f"* IMPACTS: {precip_status} conditions. Ideal for field work." 
        if wind < 5.0 and 'rain' not in desc.lower() else 
        f"* IMPACTS: Hazardous for spraying or sensitive tasks."
    )
    return overview

# Agri and Weather Data
@main_bp.route("/agri-dashboard")
@login_required
def agri_dashboard():
    # 1. Fetch Live Weather (Thane)
    # Get free key from openweathermap.org
    weather_api_key = "2baab2dc7ad18ffef8b81c014e893e1c" 
    weather_url = f"https://api.openweathermap.org/data/2.5/weather?q=Thane&units=metric&appid={weather_api_key}"
    
    weather_data = {"temp": "--", "desc": "Offline", "location": "Thane", "humidity": "--"}
    try:
        w_res = requests.get(weather_url, timeout=3).json()
        if w_res.get("main"):
            weather_data = {
                "temp": round(w_res['main']['temp']),
                "desc": w_res['weather'][0]['description'].capitalize(),
                "location": w_res['name'],
                "humidity": w_res['main']['humidity']
            }
    except:
        pass

    # 2. Agricultural Commodity Prices
    # These can be pulled from your DB or a Scraper later
    commodities = [
        {"name": "Onion", "price": "2,450", "unit": "Quintal", "trend": "up"},
        {"name": "Cotton", "price": "7,100", "unit": "Quintal", "trend": "down"},
        {"name": "Sugarcane", "price": "315", "unit": "Ton", "trend": "up"}
    ]

    return render_template("main/agri_dashboard.html", 
                           weather=weather_data, 
                           commodities=commodities)

# ================================================================
#  Background: PDF generation + email
# ================================================================
def _bg_pdf_email(db_cfg, mail_cfg, template_dir, articles, pub_ids, pdf_folder, settings):
    """
    Generate a PDF for each published article by visiting its real URL,
    update pdf_path in DB, then send email.

    Parameters are plain Python values only.
    """
    try:
        from app.pdf_generator import generate_pdf_from_url
    except ImportError as e:
        print(f"[BG] Cannot import app.pdf_generator: {e}")
        traceback.print_exc()
        generate_pdf_from_url = None

    pdf_paths = []

    os.makedirs(pdf_folder, exist_ok=True)
    print(f"[BG] PDF folder ready: {pdf_folder}")

    for art, pub_id in zip(articles, pub_ids):
        news_url = (art.get("news_url") or "").strip()
        safe_name = f"news_{pub_id}.pdf"
        out_path = os.path.join(pdf_folder, safe_name)

        print("=" * 80)
        print(f"[BG] Starting PDF generation for pub_id={pub_id}")
        print(f"[BG] Headline : {art.get('news_headline', '')}")
        print(f"[BG] URL      : {news_url}")
        print(f"[BG] Output   : {out_path}")

        pdf_ok = False

        if not news_url:
            print(f"[BG] pub_id={pub_id} has empty news_url. Skipping PDF.")
        elif not news_url.startswith(("http://", "https://")):
            print(f"[BG] pub_id={pub_id} has invalid URL: {news_url}")
        elif generate_pdf_from_url is None:
            print(f"[BG] pdf_generator import failed for pub_id={pub_id}. Skipping PDF.")
        else:
            try:
                pdf_ok = generate_pdf_from_url(url=news_url, output_path=out_path)
                print(f"[BG] generate_pdf_from_url returned {pdf_ok} for pub_id={pub_id}")
            except Exception as e:
                print(f"[BG] PDF generation exception for pub_id={pub_id}: {e}")
                traceback.print_exc()
                pdf_ok = False

        if pdf_ok and os.path.exists(out_path):
            try:
                size = os.path.getsize(out_path)
                print(f"[BG] PDF file exists for pub_id={pub_id}, size={size} bytes")

                c = _raw_conn(db_cfg)
                cur = c.cursor()
                cur.execute(
                    "UPDATE published_news SET pdf_path=%s WHERE id=%s",
                    (safe_name, pub_id),
                )
                c.commit()
                cur.close()
                c.close()

                print(f"[BG] DB updated with pdf_path={safe_name} for pub_id={pub_id}")
                pdf_paths.append(out_path)

            except Exception as e:
                print(f"[BG] DB update failed for pub_id={pub_id}: {e}")
                traceback.print_exc()
                pdf_paths.append(None)
        else:
            if os.path.exists(out_path):
                try:
                    print(
                        f"[BG] PDF generation returned False but file exists: {out_path}, "
                        f"size={os.path.getsize(out_path)}"
                    )
                except Exception:
                    pass

            print(f"[BG] PDF failed for pub_id={pub_id}, url={news_url}")
            pdf_paths.append(None)

    # ── Send email ───────────────────────────────────────────
    if not settings.get("email_on_publish", 1):
        print("[BG] email_on_publish=0 — skipping email.")
        return

    try:
        _send_email_bg(
            articles=articles,
            pub_ids=pub_ids,
            pdf_paths=pdf_paths,
            settings=settings,
            mail_cfg=mail_cfg,
            template_dir=template_dir,
        )
    except Exception as e:
        print(f"[BG] Email send failed: {e}")
        traceback.print_exc()
        return

    # Mark email sent in DB
    try:
        c = _raw_conn(db_cfg)
        cur = c.cursor()
        for pid in pub_ids:
            cur.execute(
                "UPDATE published_news SET email_sent=1, email_sent_at=NOW() WHERE id=%s",
                (pid,),
            )
        c.commit()
        cur.close()
        c.close()
        print(f"[BG] email_sent marked for {len(pub_ids)} articles.")
    except Exception as e:
        print(f"[BG] Mark email_sent error: {e}")
        traceback.print_exc()


# ================================================================
#  Email helpers
# ================================================================
def _render_email_template(template_dir: str, news_items: list, date_label: str) -> str:
    from jinja2 import Environment, FileSystemLoader

    env = Environment(loader=FileSystemLoader(template_dir))
    tmpl = env.get_template("email_template.html")
    return tmpl.render(news_items=news_items, date_label=date_label)


def _smtp_send(mail_cfg: dict, msg, recipients: list):
    with smtplib.SMTP(mail_cfg["MAIL_SERVER"], mail_cfg["MAIL_PORT"]) as s:
        s.ehlo()
        if mail_cfg.get("MAIL_USE_TLS", True):
            s.starttls()
        s.login(mail_cfg["MAIL_USERNAME"], mail_cfg["MAIL_PASSWORD"])
        s.sendmail(msg["From"], recipients, msg.as_string())
        print(f"[EMAIL] Sent to: {recipients}")


def _send_email_bg(articles, pub_ids, pdf_paths, settings, mail_cfg, template_dir):
    to = settings.get("email_recipient") or "niyati.b@seamlessautomations.com"
    cc_raw = settings.get("email_cc") or ""
    cc = [e.strip() for e in cc_raw.split(",") if e.strip()]
    pfx = settings.get("email_subject_prefix") or "Daily News Alert"
    mode = settings.get("publish_mode", "manual")
    date_label = datetime.now().strftime("%d %B %Y")

    if mode == "auto":
        base = mail_cfg.get("BASE_URL", "http://127.0.0.1:5000")
        items = [
            dict(a, pdf_view_url=f"{base}/download-pdf/{pid}")
            for a, pid in zip(articles, pub_ids)
        ]
        html_body = _render_email_template(template_dir, items, date_label)
    else:
        html_body = _render_email_template(template_dir, list(articles), date_label)

    msg = MIMEMultipart("mixed")
    msg["Subject"] = f"{pfx} — {date_label}"
    msg["From"] = mail_cfg.get("MAIL_FROM", mail_cfg.get("MAIL_USERNAME", ""))
    msg["To"] = to
    if cc:
        msg["Cc"] = ", ".join(cc)

    msg.attach(MIMEText(html_body, "html", "utf-8"))

    # Attach PDFs in manual mode
    if mode != "auto":
        for p in pdf_paths:
            if p and os.path.exists(p):
                with open(p, "rb") as f:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f'attachment; filename="{os.path.basename(p)}"',
                )
                msg.attach(part)

    _smtp_send(mail_cfg, msg, [to] + cc)


# ================================================================
#  Background scraper
# ================================================================
def _bg_scraper(db_cfg: dict, instance_path: str):
    global _scraper_state
    with _scraper_lock:
        _scraper_state.update(
            {"running": True, "message": "Scraper running…", "success": None}
        )

    try:
        from app.news_scraper import run_news_scraper

        result = run_news_scraper(db_config=db_cfg, instance_path=instance_path)
        with _scraper_lock:
            _scraper_state.update(
                {
                    "success": result.get("success", False),
                    "message": result.get("message", "Scraper finished."),
                }
            )
    except Exception as e:
        with _scraper_lock:
            _scraper_state.update({"success": False, "message": f"Scraper error: {e}"})
        traceback.print_exc()
    finally:
        with _scraper_lock:
            _scraper_state["running"] = False


# ================================================================
#  Routes
# ================================================================
@main_bp.route("/")
def index():
    return render_template("main/landing.html")

@main_bp.route("/home")
@login_required
def home():
    api_key = "2baab2dc7ad18ffef8b81c014e893e1c"
    
    # 1. PARAMETER CAPTURE
    # Weather search
    search_query = request.args.get('city_search', '').strip()
    
    # Commodity filters
    selected_id = request.args.get('cmdt_id')
    selected_year = request.args.get('year', '2026')
    selected_month = request.args.get('month', '1')

    # 2. WEATHER LOGIC
    city_list = ['Mumbai', 'Pune', 'Nashik']
    if search_query:
        city_list.append(search_query)
    else:
        city_list.append("Select City")

    weather_cards = []
    for city in city_list:
        card_data = {
            "location": city, 
            "temp": "--", 
            "desc": "Waiting for input" if city == "Select City" else "Loading...", 
            "icon": "01d", 
            "overview": "Enter a city name to see weather advisories." if city == "Select City" else "Fetching data..."
        }
        
        if city != "Select City":
            try:
                geo_url = f"http://api.openweathermap.org/geo/1.0/direct?q={city}&limit=1&appid={api_key}"
                geo_resp = requests.get(geo_url, timeout=5).json()
                
                if geo_resp:
                    lat, lon = geo_resp[0]['lat'], geo_resp[0]['lon']
                    w_url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&units=metric&appid={api_key}"
                    w_resp = requests.get(w_url, timeout=5).json()
                    
                    if w_resp.get("main"):
                        weather_desc = w_resp['weather'][0]['description'].title()
                        temp = round(w_resp['main']['temp'])
                        hum = w_resp['main']['humidity']
                        wind = w_resp['wind']['speed']
                        
                        card_data.update({
                            "temp": temp,
                            "desc": weather_desc,
                            "icon": w_resp['weather'][0]['icon'],
                            "overview": get_weather_overview(temp, hum, wind, weather_desc)
                        })
            except Exception as e:
                print(f"Weather Error for {city}: {e}")
        
        weather_cards.append(card_data)

    # 3. COMMODITY DROPDOWN LOGIC (From Local JSON)
    all_options = []
    try:
        # Current file: app/routes/main.py
        current_file_path = os.path.abspath(__file__) 
        # Up 1: app/routes | Up 2: app | Up 3: Project Root
        project_root = os.path.abspath(os.path.join(current_file_path, "../../../")) 
        json_path = os.path.join(project_root, 'agridata.json')
        print(f"DEBUG: Path check -> {json_path}")
        
        if os.path.exists(json_path):
            with open(json_path, 'r', encoding='utf-8') as f: # Added encoding for safety
                agri_json = json.load(f)
                all_options = agri_json.get('data', [])
                print(f"DEBUG: Success! Found {len(all_options)} commodities in JSON.")
        else:
            # Fixed the variable name from base_dir to project_root
            print(f"DEBUG: FILE MISSING at {json_path}")
            
    except Exception as e:
        print(f"JSON Read Error: {e}")
            
    except Exception as e:
        print(f"JSON Read Error: {e}")

    # 4. COMMODITY PRICE API LOGIC (Live Call)
    state_data = []
    cmdt_title = ""

    if selected_id:
        url = "https://api.agmarknet.gov.in/v1/price-trend/wholesale-prices-monthly"
        params = {
            'report_mode': 'Statewise',
            'commodity': selected_id,
            'year': selected_year,
            'month': selected_month,
            'state': '0',
            'district': '0',
            'export': 'false'
        }
        headers = {
            'origin': 'https://www.agmarknet.gov.in', 
            'referer': 'https://www.agmarknet.gov.in/'
        }
        
        try:
            resp = requests.get(url, params=params, headers=headers, timeout=10)
            print(f"DEBUG: API Status Code: {resp.status_code}") # Check if 200
            data=resp.json()
            if resp.get("success"):
                state_data = resp.get("rows", [])
                cmdt_title = resp.get("title", "Price Analysis")
                print(f"DEBUG: Received {len(state_data)} rows from Agmarknet")
        except Exception as e:
            print(f"Agmarknet API Error: {e}")

    # 5. DATABASE LOGIC (Pending News)
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT COUNT(*) as count FROM non_published_news")
        pending_count = cursor.fetchone()["count"]

        cursor.execute("SELECT * FROM non_published_news ORDER BY id DESC LIMIT 5")
        recent_news = cursor.fetchall()
    except Exception as e:
        print(f"Database Error: {e}")
        pending_count = 0
        recent_news = []
    finally:
        cursor.close()

    # 6. RENDER TEMPLATE
    return render_template(
        "main/home.html", 
        weather_cards=weather_cards,
        search_query=search_query,
        all_options=all_options,      # For the dropdown
        state_data=state_data,        # For the table
        table_title=cmdt_title,       # Table heading
        selected_id=selected_id,      # To keep dropdown state
        selected_year=selected_year,  # To keep dropdown state
        selected_month=selected_month,# To keep dropdown state
        pending_count=pending_count,
        recent_news=recent_news
    )


# ── Keywords ──────────────────────────────────────────────────
@main_bp.route("/view-keywords", methods=["GET", "POST"])
@login_required
def view_keywords():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == "POST":
        action = request.form.get("action")

        if action == "add":
            sr_no = request.form.get("sr_no", "").strip()
            kw = request.form.get("keyword", "").strip()
            if not sr_no or not kw:
                flash("Both Sr. No and Keyword are required.", "danger")
            else:
                try:
                    sr_no = int(sr_no)
                    cursor.execute("SELECT id FROM keywords WHERE sr_no=%s", (sr_no,))
                    if cursor.fetchone():
                        flash("Sr. No already exists.", "danger")
                    else:
                        cursor.execute(
                            "INSERT INTO keywords(sr_no, keyword) VALUES(%s, %s)",
                            (sr_no, kw),
                        )
                        db.commit()
                        flash("Keyword added.", "success")
                except ValueError:
                    flash("Sr. No must be a number.", "danger")
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_keywords"))

        elif action == "edit":
            kid = request.form.get("keyword_id", "").strip()
            kw = request.form.get("edit_keyword", "").strip()
            if not kid or not kw:
                flash("Keyword ID and value required.", "danger")
            else:
                try:
                    cursor.execute("UPDATE keywords SET keyword=%s WHERE id=%s", (kw, kid))
                    db.commit()
                    flash(
                        "Updated." if cursor.rowcount else "Not found.",
                        "success" if cursor.rowcount else "warning",
                    )
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_keywords"))

        elif action == "bulk_delete":
            ids = request.form.getlist("selected_keywords")
            if not ids:
                flash("Select at least one.", "warning")
            else:
                try:
                    ph = ",".join(["%s"] * len(ids))
                    cursor.execute(f"DELETE FROM keywords WHERE id IN ({ph})", tuple(ids))
                    db.commit()
                    flash("Deleted.", "success")
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_keywords"))

    cursor.execute("SELECT id, sr_no, keyword FROM keywords ORDER BY sr_no ASC")
    keywords = cursor.fetchall()
    cursor.close()
    return render_template("main/view_keywords.html", keywords=keywords)


# ── Websites ───────────────────────────────────────────────────
@main_bp.route("/view-websites", methods=["GET", "POST"])
@login_required
def view_websites():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == "POST":
        action = request.form.get("action")

        if action == "add":
            sr_no = request.form.get("sr_no", "").strip()
            val = request.form.get("websites", "").strip()
            if not sr_no or not val:
                flash("Both fields required.", "danger")
            else:
                try:
                    sr_no = int(sr_no)
                    cursor.execute("SELECT id FROM websites WHERE sr_no=%s", (sr_no,))
                    if cursor.fetchone():
                        flash("Sr. No exists.", "danger")
                    else:
                        cursor.execute(
                            "INSERT INTO websites(sr_no, websites) VALUES(%s, %s)",
                            (sr_no, val),
                        )
                        db.commit()
                        flash("Website added.", "success")
                except ValueError:
                    flash("Sr. No must be a number.", "danger")
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_websites"))

        elif action == "edit":
            wid = request.form.get("websites_id", "").strip()
            val = request.form.get("edit_websites", "").strip()
            if not wid or not val:
                flash("Both fields required.", "danger")
            else:
                try:
                    cursor.execute("UPDATE websites SET websites=%s WHERE id=%s", (val, wid))
                    db.commit()
                    flash(
                        "Updated." if cursor.rowcount else "Not found.",
                        "success" if cursor.rowcount else "warning",
                    )
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_websites"))

        elif action == "bulk_delete":
            ids = request.form.getlist("selected_websites")
            if not ids:
                flash("Select at least one.", "warning")
            else:
                try:
                    ph = ",".join(["%s"] * len(ids))
                    cursor.execute(f"DELETE FROM websites WHERE id IN ({ph})", tuple(ids))
                    db.commit()
                    flash("Deleted.", "success")
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_websites"))

    cursor.execute("SELECT id, sr_no, websites FROM websites ORDER BY sr_no ASC")
    websites = cursor.fetchall()
    cursor.close()
    return render_template("main/view_websites.html", websites=websites)


# ── News Type ──────────────────────────────────────────────────
@main_bp.route("/view-news-type", methods=["GET", "POST"])
@login_required
def view_news_type():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == "POST":
        action = request.form.get("action")

        if action == "add":
            sr_no = request.form.get("sr_no", "").strip()
            val = request.form.get("news_type", "").strip()
            if not sr_no or not val:
                flash("Both fields required.", "danger")
            else:
                try:
                    sr_no = int(sr_no)
                    cursor.execute("SELECT id FROM news WHERE sr_no=%s", (sr_no,))
                    if cursor.fetchone():
                        flash("Sr. No exists.", "danger")
                    else:
                        cursor.execute(
                            "INSERT INTO news(sr_no, news_type) VALUES(%s, %s)",
                            (sr_no, val),
                        )
                        db.commit()
                        flash("News type added.", "success")
                except ValueError:
                    flash("Sr. No must be a number.", "danger")
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_news_type"))

        elif action == "edit":
            ntid = request.form.get("news_type_id", "").strip()
            val = request.form.get("edit_news_type", "").strip()
            if not ntid or not val:
                flash("Both fields required.", "danger")
            else:
                try:
                    cursor.execute("UPDATE news SET news_type=%s WHERE id=%s", (val, ntid))
                    db.commit()
                    flash(
                        "Updated." if cursor.rowcount else "Not found.",
                        "success" if cursor.rowcount else "warning",
                    )
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_news_type"))

        elif action == "bulk_delete":
            ids = request.form.getlist("selected_news_types")
            if not ids:
                flash("Select at least one.", "warning")
            else:
                try:
                    ph = ",".join(["%s"] * len(ids))
                    cursor.execute(f"DELETE FROM news WHERE id IN ({ph})", tuple(ids))
                    db.commit()
                    flash("Deleted.", "success")
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_news_type"))

    cursor.execute("SELECT id, sr_no, news_type FROM news ORDER BY sr_no ASC")
    news_types = cursor.fetchall()
    cursor.close()
    return render_template("main/view_news_type.html", news_types=news_types)


# ── Commodity ──────────────────────────────────────────────────
@main_bp.route("/view-commodity", methods=["GET", "POST"])
@login_required
def view_commodity():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == "POST":
        action = request.form.get("action")

        if action == "add":
            sr_no = request.form.get("sr_no", "").strip()
            val = request.form.get("commodity", "").strip()
            if not sr_no or not val:
                flash("Both fields required.", "danger")
            else:
                try:
                    sr_no = int(sr_no)
                    cursor.execute("SELECT id FROM commodity WHERE sr_no=%s", (sr_no,))
                    if cursor.fetchone():
                        flash("Sr. No exists.", "danger")
                    else:
                        cursor.execute(
                            "INSERT INTO commodity(sr_no, commodity) VALUES(%s, %s)",
                            (sr_no, val),
                        )
                        db.commit()
                        flash("Commodity added.", "success")
                except ValueError:
                    flash("Sr. No must be a number.", "danger")
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_commodity"))

        elif action == "edit":
            cid = request.form.get("commodity_id", "").strip()
            val = request.form.get("edit_commodity", "").strip()
            if not cid or not val:
                flash("Both fields required.", "danger")
            else:
                try:
                    cursor.execute("UPDATE commodity SET commodity=%s WHERE id=%s", (val, cid))
                    db.commit()
                    flash(
                        "Updated." if cursor.rowcount else "Not found.",
                        "success" if cursor.rowcount else "warning",
                    )
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_commodity"))

        elif action == "bulk_delete":
            ids = request.form.getlist("selected_commodities")
            if not ids:
                flash("Select at least one.", "warning")
            else:
                try:
                    ph = ",".join(["%s"] * len(ids))
                    cursor.execute(f"DELETE FROM commodity WHERE id IN ({ph})", tuple(ids))
                    db.commit()
                    flash("Deleted.", "success")
                except Exception as e:
                    db.rollback()
                    flash(f"Error: {e}", "danger")

            cursor.close()
            return redirect(url_for("main.view_commodity"))

    cursor.execute("SELECT id, sr_no, commodity FROM commodity ORDER BY sr_no ASC")
    commodities = cursor.fetchall()
    cursor.close()
    return render_template("main/view_commodity.html", commodities=commodities)


# ================================================================
#  All Non-Published News — GET
# ================================================================
@main_bp.route("/all-non-published-news")
@login_required
def all_non_published_news():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    try:
        cursor.execute("SELECT * FROM user_settings WHERE id=1")
        settings = cursor.fetchone() or {}
    except Exception:
        settings = {}

    cats_str = settings.get("content_categories", "all") or "all"
    cats = [c.strip().lower() for c in cats_str.split(",") if c.strip()]
    page = max(1, int(request.args.get("page", 1)))

    try:
        if "all" in cats:
            cursor.execute(
                "SELECT COUNT(*) AS cnt FROM non_published_news WHERE published=0"
            )
        else:
            ph = ",".join(["%s"] * len(cats))
            cursor.execute(
                f"SELECT COUNT(*) AS cnt FROM non_published_news "
                f"WHERE published=0 AND LOWER(news_type) IN ({ph})",
                tuple(cats),
            )

        total = cursor.fetchone()["cnt"]
        total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
        page = min(page, total_pages)
        offset = (page - 1) * PER_PAGE

        if "all" in cats:
            cursor.execute(
                "SELECT id, news_date, news_type, news_headline, "
                "news_text, news_url, keywords, date_of_insert "
                "FROM non_published_news WHERE published=0 "
                "ORDER BY date_of_insert DESC LIMIT %s OFFSET %s",
                (PER_PAGE, offset),
            )
        else:
            ph = ",".join(["%s"] * len(cats))
            cursor.execute(
                f"SELECT id, news_date, news_type, news_headline, "
                f"news_text, news_url, keywords, date_of_insert "
                f"FROM non_published_news WHERE published=0 "
                f"AND LOWER(news_type) IN ({ph}) "
                f"ORDER BY date_of_insert DESC LIMIT %s OFFSET %s",
                tuple(cats) + (PER_PAGE, offset),
            )

        news = cursor.fetchall()

    except Exception as e:
        flash(f"Error loading news: {e}", "danger")
        news, total, total_pages, page = [], 0, 1, 1
    finally:
        cursor.close()

    with _scraper_lock:
        scrape_running = _scraper_state["running"]

    return render_template(
        "main/all_non_published_news.html",
        news=news,
        scrape_running=scrape_running,
        page=page,
        total_pages=total_pages,
        total=total,
        per_page=PER_PAGE,
    )


# ================================================================
#  All Non-Published News — POST (publish / delete)
# ================================================================
@main_bp.route("/all-non-published-news/actions", methods=["POST"])
@login_required
def all_non_published_news_actions():
    db = get_db()
    cursor = db.cursor(dictionary=True)
    action = request.form.get("action")
    ids = request.form.getlist("selected_news")

    if not ids:
        flash("Please select at least one article.", "warning")
        cursor.close()
        return redirect(url_for("main.all_non_published_news"))

    ph = ",".join(["%s"] * len(ids))

    try:
        # ── DELETE ───────────────────────────────────────────────
        if action == "delete":
            cursor.execute(
                f"DELETE FROM non_published_news WHERE id IN ({ph})",
                tuple(ids),
            )
            db.commit()
            flash(f"{cursor.rowcount} article(s) deleted.", "success")

        # ── PUBLISH ──────────────────────────────────────────────
        elif action == "publish":
            cursor.execute(
                f"SELECT id, news_date, news_type, news_headline, "
                f"news_text, news_url, keywords, date_of_insert "
                f"FROM non_published_news WHERE id IN ({ph})",
                tuple(ids),
            )
            articles = cursor.fetchall()

            if not articles:
                flash("No articles found for selected IDs.", "warning")
                cursor.close()
                return redirect(url_for("main.all_non_published_news"))

            # Log URLs before publish
            for art in articles:
                print(
                    f"[PUBLISH] source_id={art['id']}, "
                    f"headline={art.get('news_headline', '')}, "
                    f"url={art.get('news_url', '')}"
                )

            try:
                cursor.execute("SELECT * FROM user_settings WHERE id=1")
                settings = cursor.fetchone() or {}
            except Exception:
                settings = {}

            pdf_folder = current_app.config.get(
                "PDF_FOLDER",
                os.path.join(current_app.root_path, "static", "pdfs"),
            )
            os.makedirs(pdf_folder, exist_ok=True)

            now = datetime.now()
            pub_ids = []

            # STEP 1: insert into published_news immediately
            for art in articles:
                cursor.execute(
                    "INSERT INTO published_news "
                    "(source_id, news_date, news_type, news_headline, "
                    "news_text, news_url, keywords, date_of_insert, published_at) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                    (
                        art["id"],
                        art["news_date"],
                        art["news_type"],
                        art["news_headline"],
                        art["news_text"],
                        art["news_url"],
                        art["keywords"],
                        art["date_of_insert"],
                        now,
                    ),
                )
                db.commit()
                pub_ids.append(cursor.lastrowid)

            # STEP 2: delete from non_published_news immediately
            cursor.execute(
                f"DELETE FROM non_published_news WHERE id IN ({ph})",
                tuple(ids),
            )
            db.commit()
            print(f"[PUBLISH] Deleted {len(ids)} rows from non_published_news.")

            # STEP 3: collect config before leaving request context
            db_cfg = _get_db_cfg()
            cfg = current_app.config
            mail_cfg = {
                "MAIL_SERVER": cfg.get("MAIL_SERVER", "smtp.gmail.com"),
                "MAIL_PORT": cfg.get("MAIL_PORT", 587),
                "MAIL_USE_TLS": cfg.get("MAIL_USE_TLS", True),
                "MAIL_USERNAME": cfg.get("MAIL_USERNAME", ""),
                "MAIL_PASSWORD": cfg.get("MAIL_PASSWORD", ""),
                "MAIL_FROM": cfg.get("MAIL_FROM", cfg.get("MAIL_USERNAME", "")),
                "BASE_URL": cfg.get("BASE_URL", "http://127.0.0.1:5000"),
            }
            template_dir = os.path.join(current_app.root_path, "templates", "main")

            # STEP 4: background PDF generation
            thread = threading.Thread(
                target=_bg_pdf_email,
                args=(
                    db_cfg,
                    mail_cfg,
                    template_dir,
                    list(articles),
                    list(pub_ids),
                    pdf_folder,
                    dict(settings),
                ),
                daemon=False,
            )
            thread.start()

            flash(
                f"{len(articles)} article(s) published successfully. "
                f"They were moved to Today's Published News, removed from Non Published News, "
                f"and PDF generation from the original news site has started.",
                "success",
            )

    except Exception as e:
        db.rollback()
        flash(f"Error during publish: {e}", "danger")
        traceback.print_exc()
    finally:
        cursor.close()

    return redirect(url_for("main.all_non_published_news"))


# ================================================================
#  Refresh News — background scraper
# ================================================================
@main_bp.route("/refresh-news", methods=["POST"])
@login_required
def refresh_news():
    with _scraper_lock:
        if _scraper_state["running"]:
            flash("Scraper is already running.", "warning")
            return redirect(url_for("main.all_non_published_news"))

    db_cfg = _get_db_cfg()
    instance_path = current_app.instance_path

    threading.Thread(
        target=_bg_scraper,
        args=(db_cfg, instance_path),
        daemon=True,
    ).start()

    flash("News refresh started in the background. Page will auto-update when complete.", "info")
    return redirect(url_for("main.all_non_published_news"))


@main_bp.route("/refresh-news/status")
@login_required
def refresh_news_status():
    with _scraper_lock:
        state = dict(_scraper_state)
    return jsonify(state)


# # ================================================================
# #  Today's Published News
# # ================================================================
# @main_bp.route("/today-published-news")
# @login_required
# def today_published_news():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     today = date.today()
#     page = max(1, int(request.args.get("page", 1)))

#     try:
#         cursor.execute(
#             "SELECT COUNT(*) AS cnt FROM published_news WHERE DATE(published_at)=%s",
#             (today,),
#         )
#         total = cursor.fetchone()["cnt"]
#         total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
#         page = min(page, total_pages)
#         offset = (page - 1) * PER_PAGE

#         cursor.execute(
#             "SELECT id, news_date, news_type, news_headline, "
#             "news_url, pdf_path, published_at "
#             "FROM published_news WHERE DATE(published_at)=%s "
#             "ORDER BY published_at DESC LIMIT %s OFFSET %s",
#             (today, PER_PAGE, offset),
#         )
#         news = cursor.fetchall()

#     except Exception as e:
#         flash(f"Error loading published news: {e}", "danger")
#         news, total, total_pages, page = [], 0, 1, 1
#     finally:
#         cursor.close()

#     return render_template(
#         "main/today_published_news.html",
#         news=news,
#         today=today,
#         page=page,
#         total_pages=total_pages,
#         total=total,
#         per_page=PER_PAGE,
#     )


# # ================================================================
# #  Check PDF ready
# # ================================================================
# @main_bp.route("/check-pdf/<int:news_id>")
# @login_required
# def check_pdf_ready(news_id):
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     try:
#         cursor.execute(
#             "SELECT pdf_path FROM published_news WHERE id=%s",
#             (news_id,),
#         )
#         row = cursor.fetchone()
#     finally:
#         cursor.close()

#     ready = False
#     if row and row.get("pdf_path"):
#         pdf_folder = current_app.config.get(
#             "PDF_FOLDER",
#             os.path.join(current_app.root_path, "static", "pdfs"),
#         )
#         fp = os.path.join(pdf_folder, row["pdf_path"])
#         ready = os.path.exists(fp) and os.path.getsize(fp) > 500

#     return jsonify({"ready": ready})


# # ================================================================
# #  Download PDF
# # ================================================================
# @main_bp.route("/download-pdf/<int:news_id>")
# @login_required
# def download_pdf(news_id):
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     try:
#         cursor.execute(
#             "SELECT pdf_path FROM published_news WHERE id=%s",
#             (news_id,),
#         )
#         row = cursor.fetchone()
#     finally:
#         cursor.close()

#     if not row or not row["pdf_path"]:
#         flash("PDF is still being generated — please try again in a moment.", "warning")
#         return redirect(url_for("main.today_published_news"))

#     pdf_folder = current_app.config.get(
#         "PDF_FOLDER",
#         os.path.join(current_app.root_path, "static", "pdfs"),
#     )
#     return send_from_directory(pdf_folder, row["pdf_path"], as_attachment=True)


# # ================================================================
# #  Manual re-send email for today
# # ================================================================
# @main_bp.route("/send-email-today")
# @login_required
# def send_email_today():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     today = date.today()

#     try:
#         cursor.execute(
#             "SELECT id, news_date, news_type, news_headline, news_url, pdf_path "
#             "FROM published_news WHERE DATE(published_at)=%s "
#             "ORDER BY published_at DESC",
#             (today,),
#         )
#         articles = cursor.fetchall()

#         if not articles:
#             flash("No published news for today.", "warning")
#             cursor.close()
#             return redirect(url_for("main.today_published_news"))

#         try:
#             cursor.execute("SELECT * FROM user_settings WHERE id=1")
#             settings = cursor.fetchone() or {}
#         except Exception:
#             settings = {}

#         cfg = current_app.config
#         mail_cfg = {
#             "MAIL_SERVER": cfg.get("MAIL_SERVER", "smtp.gmail.com"),
#             "MAIL_PORT": cfg.get("MAIL_PORT", 587),
#             "MAIL_USE_TLS": cfg.get("MAIL_USE_TLS", True),
#             "MAIL_USERNAME": cfg.get("MAIL_USERNAME", ""),
#             "MAIL_PASSWORD": cfg.get("MAIL_PASSWORD", ""),
#             "MAIL_FROM": cfg.get("MAIL_FROM", cfg.get("MAIL_USERNAME", "")),
#             "BASE_URL": cfg.get("BASE_URL", "http://127.0.0.1:5000"),
#         }

#         pdf_folder = cfg.get(
#             "PDF_FOLDER",
#             os.path.join(current_app.root_path, "static", "pdfs"),
#         )
#         template_dir = os.path.join(current_app.root_path, "templates", "main")
#         pdf_paths = [
#             os.path.join(pdf_folder, a["pdf_path"])
#             for a in articles
#             if a.get("pdf_path")
#         ]
#         pub_ids = [a["id"] for a in articles]

#         _send_email_bg(
#             articles=list(articles),
#             pub_ids=pub_ids,
#             pdf_paths=pdf_paths,
#             settings=dict(settings),
#             mail_cfg=mail_cfg,
#             template_dir=template_dir,
#         )

#         flash("Email sent successfully.", "success")

#     except Exception as e:
#         flash(f"Failed to send email: {e}", "danger")
#         traceback.print_exc()
#     finally:
#         cursor.close()

#     return redirect(url_for("main.today_published_news"))


# # ================================================================
# #  User Settings
# # ================================================================
# @main_bp.route("/user-settings", methods=["GET", "POST"])
# @login_required
# def user_settings():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == "POST":
#         try:
#             cursor.execute(
#                 "INSERT INTO user_settings "
#                 "(id, run_frequency, custom_frequency, scraper_enabled, "
#                 "publish_mode, content_categories, email_recipient, "
#                 "email_cc, email_subject_prefix, email_on_publish) "
#                 "VALUES (1,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
#                 "ON DUPLICATE KEY UPDATE "
#                 "run_frequency=VALUES(run_frequency), "
#                 "custom_frequency=VALUES(custom_frequency), "
#                 "scraper_enabled=VALUES(scraper_enabled), "
#                 "publish_mode=VALUES(publish_mode), "
#                 "content_categories=VALUES(content_categories), "
#                 "email_recipient=VALUES(email_recipient), "
#                 "email_cc=VALUES(email_cc), "
#                 "email_subject_prefix=VALUES(email_subject_prefix), "
#                 "email_on_publish=VALUES(email_on_publish)",
#                 (
#                     request.form.get("run_frequency", "1"),
#                     request.form.get("custom_frequency") or None,
#                     1 if request.form.get("scraper_enabled") else 0,
#                     request.form.get("publish_mode", "manual"),
#                     ",".join(request.form.getlist("content_categories")) or "all",
#                     request.form.get("email_recipient", "").strip(),
#                     request.form.get("email_cc", "").strip(),
#                     request.form.get("email_subject_prefix", "Daily News Alert").strip(),
#                     1 if request.form.get("email_on_publish") else 0,
#                 ),
#             )
#             db.commit()
#             flash("Settings saved.", "success")
#         except Exception as e:
#             db.rollback()
#             flash(f"Error: {e}", "danger")
#         finally:
#             cursor.close()

#         return redirect(url_for("main.user_settings"))

#     try:
#         cursor.execute("SELECT * FROM user_settings WHERE id=1")
#         settings = cursor.fetchone() or {}
#     except Exception:
#         settings = {}
#     finally:
#         cursor.close()

#     return render_template("main/user_settings.html", settings=settings)


# def get_settings():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)
#     try:
#         cursor.execute("SELECT * FROM user_settings WHERE id=1")
#         return cursor.fetchone() or {}
#     except Exception:
#         return {}
#     finally:
#         cursor.close()
# =============================================================================
#  Today's Published News — paginated
# =============================================================================
 
@main_bp.route("/today-published-news")
@login_required
def today_published_news():
    db = get_db(); cursor = db.cursor(dictionary=True)
    today = date.today()
    page  = max(1, int(request.args.get("page", 1)))
    try:
        cursor.execute(
            "SELECT COUNT(*) AS cnt FROM published_news WHERE DATE(published_at)=%s",
            (today,))
        total = cursor.fetchone()["cnt"]
        total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
        page   = min(page, total_pages)
        offset = (page - 1) * PER_PAGE
        cursor.execute(
            "SELECT id, news_date, news_type, news_headline, "
            "news_url, pdf_path, published_at "
            "FROM published_news WHERE DATE(published_at)=%s "
            "ORDER BY published_at DESC LIMIT %s OFFSET %s",
            (today, PER_PAGE, offset))
        news = cursor.fetchall()
    except Exception as e:
        flash(f"Error: {e}", "danger")
        news, total, total_pages, page = [], 0, 1, 1
    finally:
        cursor.close()
    return render_template(
        "main/today_published_news.html",
        news=news, today=today,
        page=page, total_pages=total_pages,
        total=total, per_page=PER_PAGE,
    )
 
 
# =============================================================================
#  Check PDF ready — polled by JS every 8 s
# =============================================================================
 
@main_bp.route("/check-pdf/<int:news_id>")
@login_required
def check_pdf_ready(news_id):
    db = get_db(); cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT pdf_path FROM published_news WHERE id=%s", (news_id,))
        row = cursor.fetchone()
    finally:
        cursor.close()
 
    ready = False
    if row and row.get("pdf_path"):
        pdf_folder = current_app.config.get(
            "PDF_FOLDER", os.path.join(current_app.root_path, "static", "pdfs"))
        fp    = os.path.join(pdf_folder, row["pdf_path"])
        ready = os.path.exists(fp) and os.path.getsize(fp) > 500
 
    return jsonify({"ready": ready})
 
 
# =============================================================================
#  Download PDF
# =============================================================================
 
@main_bp.route("/download-pdf/<int:news_id>")
@login_required
def download_pdf(news_id):
    db = get_db(); cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT pdf_path FROM published_news WHERE id=%s", (news_id,))
        row = cursor.fetchone()
    finally:
        cursor.close()
 
    if not row or not row["pdf_path"]:
        flash("PDF is still being generated — please try again in a moment.", "warning")
        return redirect(url_for("main.today_published_news"))
 
    pdf_folder = current_app.config.get(
        "PDF_FOLDER", os.path.join(current_app.root_path, "static", "pdfs"))
    return send_from_directory(pdf_folder, row["pdf_path"], as_attachment=True)
 
 
# =============================================================================
#  Manual re-send email for today
# =============================================================================
 
@main_bp.route("/send-email-today")
@login_required
def send_email_today():
    db = get_db(); cursor = db.cursor(dictionary=True)
    today = date.today()
    try:
        cursor.execute(
            "SELECT id, news_date, news_type, news_headline, news_url, pdf_path "
            "FROM published_news WHERE DATE(published_at)=%s ORDER BY published_at DESC",
            (today,))
        articles = cursor.fetchall()
        if not articles:
            flash("No published news for today.", "warning")
            cursor.close()
            return redirect(url_for("main.today_published_news"))
 
        try:
            cursor.execute("SELECT * FROM user_settings WHERE id=1")
            settings = cursor.fetchone() or {}
        except Exception:
            settings = {}
 
        cfg = current_app.config
        mail_cfg = {
            "MAIL_SERVER":   cfg.get("MAIL_SERVER",   "smtp.gmail.com"),
            "MAIL_PORT":     cfg.get("MAIL_PORT",     587),
            "MAIL_USE_TLS":  cfg.get("MAIL_USE_TLS",  True),
            "MAIL_USERNAME": cfg.get("MAIL_USERNAME", ""),
            "MAIL_PASSWORD": cfg.get("MAIL_PASSWORD", ""),
            "MAIL_FROM":     cfg.get("MAIL_FROM",     cfg.get("MAIL_USERNAME", "")),
            "BASE_URL":      cfg.get("BASE_URL",      "http://127.0.0.1:5000"),
        }
        pdf_folder   = cfg.get("PDF_FOLDER", os.path.join(current_app.root_path, "static", "pdfs"))
        template_dir = os.path.join(current_app.root_path, "templates", "main")
        pdf_paths    = [os.path.join(pdf_folder, a["pdf_path"])
                        for a in articles if a.get("pdf_path")]
        pub_ids      = [a["id"] for a in articles]
 
        _send_email(list(articles), pub_ids, pdf_paths,
                    dict(settings), mail_cfg, template_dir)
        flash("Email sent successfully.", "success")
    except Exception as e:
        flash(f"Failed to send email: {e}", "danger"); traceback.print_exc()
    finally:
        cursor.close()
    return redirect(url_for("main.today_published_news"))
 
 
# =============================================================================
#  User Settings
# =============================================================================
 
@main_bp.route("/user-settings", methods=["GET", "POST"])
@login_required
def user_settings():
    db = get_db(); cursor = db.cursor(dictionary=True)
    if request.method == "POST":
        try:
            cursor.execute(
                "INSERT INTO user_settings "
                "(id,run_frequency,custom_frequency,scraper_enabled,"
                "publish_mode,content_categories,email_recipient,"
                "email_cc,email_subject_prefix,email_on_publish) "
                "VALUES (1,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
                "ON DUPLICATE KEY UPDATE "
                "run_frequency=VALUES(run_frequency),"
                "custom_frequency=VALUES(custom_frequency),"
                "scraper_enabled=VALUES(scraper_enabled),"
                "publish_mode=VALUES(publish_mode),"
                "content_categories=VALUES(content_categories),"
                "email_recipient=VALUES(email_recipient),"
                "email_cc=VALUES(email_cc),"
                "email_subject_prefix=VALUES(email_subject_prefix),"
                "email_on_publish=VALUES(email_on_publish)",
                (
                    request.form.get("run_frequency", "1"),
                    request.form.get("custom_frequency") or None,
                    1 if request.form.get("scraper_enabled") else 0,
                    request.form.get("publish_mode", "manual"),
                    ",".join(request.form.getlist("content_categories")) or "all",
                    request.form.get("email_recipient", "").strip(),
                    request.form.get("email_cc", "").strip(),
                    request.form.get("email_subject_prefix", "Daily News Alert").strip(),
                    1 if request.form.get("email_on_publish") else 0,
                )
            )
            db.commit(); flash("Settings saved.", "success")
        except Exception as e:
            db.rollback(); flash(f"Error: {e}", "danger")
        finally:
            cursor.close()
        return redirect(url_for("main.user_settings"))
 
    try:
        cursor.execute("SELECT * FROM user_settings WHERE id=1")
        settings = cursor.fetchone() or {}
    except Exception:
        settings = {}
    finally:
        cursor.close()
    return render_template("main/user_settings.html", settings=settings)
 
 
def get_settings():
    db = get_db(); cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM user_settings WHERE id=1")
        return cursor.fetchone() or {}
    except Exception:
        return {}
    finally:
        cursor.close()