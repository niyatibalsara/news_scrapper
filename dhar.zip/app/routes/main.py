# from .auth import login_required
# from app.db import get_db
# import smtplib
# import os
# import traceback
# from datetime import date, datetime
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# from email.mime.base import MIMEBase
# from email import encoders

# from flask import Blueprint, render_template, request, redirect, url_for, flash, \
#     send_from_directory, current_app
# from .auth import login_required
# from app.db import get_db


# main_bp = Blueprint('main', __name__)


# @main_bp.route('/')
# def index():
#     return render_template('main/landing.html')


# @main_bp.route('/home')
# @login_required
# def home():
#     from datetime import date
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     today = date.today()
#     today_published_count = 0
#     today_unpublished_count = 0

#     try:
#         cursor.execute(
#             "SELECT COUNT(*) as cnt FROM news_articles WHERE published = 1 AND DATE(created_at) = %s",
#             (today,)
#         )
#         today_published_count = cursor.fetchone()['cnt']

#         cursor.execute(
#             "SELECT COUNT(*) as cnt FROM news_articles WHERE published = 0 AND DATE(created_at) = %s",
#             (today,)
#         )
#         today_unpublished_count = cursor.fetchone()['cnt']
#     except Exception as e:
#         print(f"Error loading dashboard counts: {e}")
#     finally:
#         cursor.close()

#     return render_template(
#         'main/home.html',
#         today_published_count=today_published_count,
#         today_unpublished_count=today_unpublished_count
#     )

# @main_bp.route('/view-keywords', methods=['GET', 'POST'])
# @login_required
# def view_keywords():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == 'POST':
#         action = request.form.get('action')

#         # ADD KEYWORD
#         if action == 'add':
#             sr_no = request.form.get('sr_no', '').strip()
#             keyword = request.form.get('keyword', '').strip()

#             if not sr_no or not keyword:
#                 flash('Both Sr. No and Keyword are required.', 'danger')
#                 cursor.close()
#                 return redirect(url_for('main.view_keywords'))

#             try:
#                 sr_no = int(sr_no)

#                 cursor.execute("SELECT id FROM keywords WHERE sr_no = %s", (sr_no,))
#                 existing_sr = cursor.fetchone()

#                 if existing_sr:
#                     flash('Sr. No already exists.', 'danger')
#                 else:
#                     cursor.execute(
#                         "INSERT INTO keywords (sr_no, keyword) VALUES (%s, %s)",
#                         (sr_no, keyword)
#                     )
#                     db.commit()
#                     flash('Keyword added successfully.', 'success')

#             except ValueError:
#                 flash('Sr. No must be a valid number.', 'danger')

#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while adding keyword: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_keywords'))

#         # EDIT KEYWORD
#         # elif action == 'edit':
#         #     keyword_id = request.form.get('keyword_id', '').strip()
#         #     keyword = request.form.get('keyword', '').strip()

#         #     if not keyword_id or not keyword:
#         #         flash('Keyword ID and Keyword are required.', 'danger')
#         #         cursor.close()
#         #         return redirect(url_for('main.view_keywords'))
#         elif action == 'edit':
#            keyword_id = request.form.get('keyword_id', '').strip()
#            keyword = request.form.get('edit_keyword', '').strip()  # ← changed from 'keyword'

#            if not keyword_id or not keyword:
#              flash('Keyword ID and Keyword are required.', 'danger')
#              cursor.close()
#              return redirect(url_for('main.view_keywords'))

#            try:
#                 cursor.execute(
#                     "UPDATE keywords SET keyword = %s WHERE id = %s",
#                     (keyword, keyword_id)
#                 )
#                 db.commit()

#                 if cursor.rowcount > 0:
#                     flash('Keyword updated successfully.', 'success')
#                 else:
#                     flash('Keyword not found.', 'warning')

#            except Exception as e:
#                 db.rollback()
#                 flash(f'Error while updating keyword: {str(e)}', 'danger')

#                 cursor.close()
#                 return redirect(url_for('main.view_keywords'))

#         # BULK DELETE
#         elif action == 'bulk_delete':
#             selected_ids = request.form.getlist('selected_keywords')

#             if not selected_ids:
#                 flash('Please select at least one row to delete.', 'warning')
#                 cursor.close()
#                 return redirect(url_for('main.view_keywords'))

#             try:
#                 placeholders = ','.join(['%s'] * len(selected_ids))
#                 query = f"DELETE FROM keywords WHERE id IN ({placeholders})"
#                 cursor.execute(query, tuple(selected_ids))
#                 db.commit()
#                 flash('Selected keywords deleted successfully.', 'success')

#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while deleting keywords: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_keywords'))

#     cursor.execute("SELECT id, sr_no, keyword FROM keywords ORDER BY sr_no ASC")
#     keywords = cursor.fetchall()
#     cursor.close()

#     return render_template('main/view_keywords.html', keywords=keywords)

# @main_bp.route('/view-websites', methods=['GET', 'POST'])
# @login_required
# def view_websites():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == 'POST':
#         action = request.form.get('action')

#         # ADD WEBSITE
#         if action == 'add':
#             sr_no = request.form.get('sr_no', '').strip()
#             website = request.form.get('websites', '').strip()  # Bug 1 fix: was saving to 'websites' var but using undefined 'websites'

#             if not sr_no or not website:
#                 flash('Both Sr. No and website are required.', 'danger')
#                 cursor.close()
#                 return redirect(url_for('main.view_websites'))

#             try:
#                 sr_no = int(sr_no)

#                 cursor.execute("SELECT id FROM websites WHERE sr_no = %s", (sr_no,))
#                 existing_sr = cursor.fetchone()

#                 if existing_sr:
#                     flash('Sr. No already exists.', 'danger')
#                 else:
#                     cursor.execute(
#                         "INSERT INTO websites (sr_no, websites) VALUES (%s, %s)",
#                         (sr_no, website)  # Bug 1 fix: was (sr_no, websites) — undefined variable
#                     )
#                     db.commit()
#                     flash('Website added successfully.', 'success')

#             except ValueError:
#                 flash('Sr. No must be a valid number.', 'danger')

#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while adding website: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_websites'))

#         # EDIT WEBSITE
#         elif action == 'edit':
#             websites_id = request.form.get('websites_id', '').strip()
#             website = request.form.get('edit_websites', '').strip()

#             if not websites_id or not website:
#                 flash('Website ID and website are required.', 'danger')
#                 cursor.close()
#                 return redirect(url_for('main.view_websites'))

#             try:
#                 cursor.execute(
#                     "UPDATE websites SET websites = %s WHERE id = %s",
#                     (website, websites_id)
#                 )
#                 db.commit()

#                 if cursor.rowcount > 0:
#                     flash('Website updated successfully.', 'success')
#                 else:
#                     flash('Website not found.', 'warning')

#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while updating website: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_websites'))  # Bug 2 fix: redirect was inside except block only

#         # BULK DELETE
#         elif action == 'bulk_delete':
#             selected_ids = request.form.getlist('selected_websites')

#             if not selected_ids:
#                 flash('Please select at least one row to delete.', 'warning')
#                 cursor.close()
#                 return redirect(url_for('main.view_websites'))

#             try:
#                 placeholders = ','.join(['%s'] * len(selected_ids))
#                 query = f"DELETE FROM websites WHERE id IN ({placeholders})"
#                 cursor.execute(query, tuple(selected_ids))
#                 db.commit()
#                 flash('Selected websites deleted successfully.', 'success')

#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while deleting websites: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_websites'))

#     cursor.execute("SELECT id, sr_no, websites FROM websites ORDER BY sr_no ASC")
#     websites = cursor.fetchall()  # Bug 3 fix: was storing as 'keywords' then passing undefined 'websites'
#     cursor.close()

#     return render_template('main/view_websites.html', websites=websites)

# @main_bp.route('/view-news-type', methods=['GET', 'POST'])
# @login_required
# def view_news_type():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == 'POST':
#         action = request.form.get('action')

#         if action == 'add':
#             sr_no = request.form.get('sr_no', '').strip()
#             news_type = request.form.get('news_type', '').strip()

#             if not sr_no or not news_type:
#                 flash('Both Sr. No and News Type are required.', 'danger')
#                 cursor.close()
#                 return redirect(url_for('main.view_news_type'))

#             try:
#                 sr_no = int(sr_no)
#                 cursor.execute("SELECT id FROM news WHERE sr_no = %s", (sr_no,))
#                 if cursor.fetchone():
#                     flash('Sr. No already exists.', 'danger')
#                 else:
#                     cursor.execute(
#                         "INSERT INTO news (sr_no, news_type) VALUES (%s, %s)",
#                         (sr_no, news_type)
#                     )
#                     db.commit()
#                     flash('News type added successfully.', 'success')
#             except ValueError:
#                 flash('Sr. No must be a valid number.', 'danger')
#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while adding news type: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_news_type'))

#         elif action == 'edit':
#             news_type_id = request.form.get('news_type_id', '').strip()
#             news_type = request.form.get('edit_news_type', '').strip()

#             if not news_type_id or not news_type:
#                 flash('News Type ID and News Type are required.', 'danger')
#                 cursor.close()
#                 return redirect(url_for('main.view_news_type'))

#             try:
#                 cursor.execute(
#                     "UPDATE news SET news_type = %s WHERE id = %s",
#                     (news_type, news_type_id)
#                 )
#                 db.commit()
#                 if cursor.rowcount > 0:
#                     flash('News type updated successfully.', 'success')
#                 else:
#                     flash('News type not found.', 'warning')
#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while updating news type: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_news_type'))

#         elif action == 'bulk_delete':
#             selected_ids = request.form.getlist('selected_news_types')

#             if not selected_ids:
#                 flash('Please select at least one row to delete.', 'warning')
#                 cursor.close()
#                 return redirect(url_for('main.view_news_type'))

#             try:
#                 placeholders = ','.join(['%s'] * len(selected_ids))
#                 cursor.execute(f"DELETE FROM news WHERE id IN ({placeholders})", tuple(selected_ids))
#                 db.commit()
#                 flash('Selected news types deleted successfully.', 'success')
#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while deleting news types: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_news_type'))

#     cursor.execute("SELECT id, sr_no, news_type FROM news ORDER BY sr_no ASC")
#     news_types = cursor.fetchall()
#     cursor.close()
#     return render_template('main/view_news_type.html', news_types=news_types)


# @main_bp.route('/view-commodity', methods=['GET', 'POST'])
# @login_required
# def view_commodity():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == 'POST':
#         action = request.form.get('action')

#         if action == 'add':
#             sr_no = request.form.get('sr_no', '').strip()
#             commodity = request.form.get('commodity', '').strip()

#             if not sr_no or not commodity:
#                 flash('Both Sr. No and Commodity are required.', 'danger')
#                 cursor.close()
#                 return redirect(url_for('main.view_commodity'))

#             try:
#                 sr_no = int(sr_no)
#                 cursor.execute("SELECT id FROM commodity WHERE sr_no = %s", (sr_no,))
#                 if cursor.fetchone():
#                     flash('Sr. No already exists.', 'danger')
#                 else:
#                     cursor.execute(
#                         "INSERT INTO commodity (sr_no, commodity) VALUES (%s, %s)",
#                         (sr_no, commodity)
#                     )
#                     db.commit()
#                     flash('Commodity added successfully.', 'success')
#             except ValueError:
#                 flash('Sr. No must be a valid number.', 'danger')
#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while adding commodity: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_commodity'))

#         elif action == 'edit':
#             commodity_id = request.form.get('commodity_id', '').strip()
#             commodity = request.form.get('edit_commodity', '').strip()

#             if not commodity_id or not commodity:
#                 flash('Commodity ID and Commodity are required.', 'danger')
#                 cursor.close()
#                 return redirect(url_for('main.view_commodity'))

#             try:
#                 cursor.execute(
#                     "UPDATE commodity SET commodity = %s WHERE id = %s",
#                     (commodity, commodity_id)
#                 )
#                 db.commit()
#                 if cursor.rowcount > 0:
#                     flash('Commodity updated successfully.', 'success')
#                 else:
#                     flash('Commodity not found.', 'warning')
#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while updating commodity: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_commodity'))

#         elif action == 'bulk_delete':
#             selected_ids = request.form.getlist('selected_commodities')

#             if not selected_ids:
#                 flash('Please select at least one row to delete.', 'warning')
#                 cursor.close()
#                 return redirect(url_for('main.view_commodity'))

#             try:
#                 placeholders = ','.join(['%s'] * len(selected_ids))
#                 cursor.execute(f"DELETE FROM commodity WHERE id IN ({placeholders})", tuple(selected_ids))
#                 db.commit()
#                 flash('Selected commodities deleted successfully.', 'success')
#             except Exception as e:
#                 db.rollback()
#                 flash(f'Error while deleting commodities: {str(e)}', 'danger')

#             cursor.close()
#             return redirect(url_for('main.view_commodity'))

#     cursor.execute("SELECT id, sr_no, commodity FROM commodity ORDER BY sr_no ASC")
#     commodities = cursor.fetchall()
#     cursor.close()
#     return render_template('main/view_commodity.html', commodities=commodities)

# def generate_pdf_from_url(url: str, output_path: str) -> bool:
#     """
#     Visits `url` with a headless Chromium browser, dismisses popups,
#     and saves the rendered page as a PDF to `output_path`.
#     Returns True on success, False on failure.
#     """
#     try:
#         from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

#         with sync_playwright() as p:
#             browser = p.chromium.launch(headless=True)
#             context = browser.new_context(
#                 accept_downloads=True,
#                 java_script_enabled=True,
#             )
#             page = context.new_page()

#             # Auto-dismiss dialogs (alert / confirm / prompt)
#             page.on("dialog", lambda dialog: dialog.dismiss())

#             try:
#                 page.goto(url, wait_until="networkidle", timeout=30000)
#             except PWTimeout:
#                 # If networkidle times out, try domcontentloaded
#                 page.goto(url, wait_until="domcontentloaded", timeout=20000)

#             # Try to close common cookie / GDPR / paywall overlays
#             for selector in [
#                 "button[id*='accept']", "button[class*='accept']",
#                 "button[id*='close']",  "button[class*='close']",
#                 "button[id*='agree']",  "button[class*='agree']",
#                 "[aria-label*='close']","[aria-label*='Close']",
#                 ".modal-close", ".popup-close", ".cookie-close",
#             ]:
#                 try:
#                     btn = page.locator(selector).first
#                     if btn.is_visible(timeout=1500):
#                         btn.click(timeout=1500)
#                 except Exception:
#                     pass

#             # Small wait so page settles after popup dismissal
#             page.wait_for_timeout(1500)

#             page.pdf(
#                 path=output_path,
#                 format="A4",
#                 margin={"top": "20mm", "bottom": "20mm",
#                         "left": "15mm", "right": "15mm"},
#                 print_background=True,
#             )
#             browser.close()
#         return True

#     except Exception as e:
#         print(f"[PDF ERROR] {url} → {e}")
#         traceback.print_exc()
#         return False


# # ----------------------------------------------------------------
# #  Helper — render Jinja2 HTML email template
# # ----------------------------------------------------------------
# def render_email_html(news_items: list, date_label: str) -> str:
#     from jinja2 import Environment, FileSystemLoader
#     template_dir = os.path.join(current_app.root_path, 'templates', 'main')
#     env = Environment(loader=FileSystemLoader(template_dir))
#     tmpl = env.get_template('email_template.html')
#     return tmpl.render(news_items=news_items, date_label=date_label)


# # ----------------------------------------------------------------
# #  Helper — send email with attachments
# # ----------------------------------------------------------------
# def send_news_email(news_items: list, pdf_paths: list, date_label: str):
#     cfg = current_app.config
#     to_addr = "niyati.b@seamlessautomations.com"

#     msg = MIMEMultipart('mixed')
#     msg['Subject'] = f"Daily News Alert — {date_label}"
#     msg['From']    = cfg.get('MAIL_FROM', cfg.get('MAIL_USERNAME', ''))
#     msg['To']      = to_addr

#     # HTML body
#     html_body = render_email_html(news_items, date_label)
#     msg.attach(MIMEText(html_body, 'html', 'utf-8'))

#     # Attach PDFs
#     for pdf_path in pdf_paths:
#         if pdf_path and os.path.exists(pdf_path):
#             with open(pdf_path, 'rb') as f:
#                 part = MIMEBase('application', 'octet-stream')
#                 part.set_payload(f.read())
#             encoders.encode_base64(part)
#             filename = os.path.basename(pdf_path)
#             part.add_header('Content-Disposition', f'attachment; filename="{filename}"')
#             msg.attach(part)

#     # Send via SMTP
#     with smtplib.SMTP(cfg['MAIL_SERVER'], cfg['MAIL_PORT']) as server:
#         server.ehlo()
#         if cfg.get('MAIL_USE_TLS', True):
#             server.starttls()
#         server.login(cfg['MAIL_USERNAME'], cfg['MAIL_PASSWORD'])
#         server.sendmail(msg['From'], [to_addr], msg.as_string())


# # ================================================================
# #  ROUTE: All Non-Published News  (publish action updated)
# # ================================================================
# @main_bp.route('/all-non-published-news', methods=['GET', 'POST'])
# @login_required
# def all_non_published_news():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == 'POST':
#         action       = request.form.get('action')
#         selected_ids = request.form.getlist('selected_news')

#         if not selected_ids:
#             flash('Please select at least one article.', 'warning')
#             cursor.close()
#             return redirect(url_for('main.all_non_published_news'))

#         placeholders = ','.join(['%s'] * len(selected_ids))

#         try:
#             # ── DELETE ──────────────────────────────────────────
#             if action == 'delete':
#                 cursor.execute(
#                     f"DELETE FROM non_published_news WHERE id IN ({placeholders})",
#                     tuple(selected_ids)
#                 )
#                 db.commit()
#                 flash(f'{cursor.rowcount} article(s) deleted successfully.', 'success')

#             # ── PUBLISH ─────────────────────────────────────────
#             elif action == 'publish':
#                 # 1. Fetch the selected rows
#                 cursor.execute(
#                     f"""SELECT id, news_date, news_type, news_headline,
#                                news_text, news_url, keywords, date_of_insert
#                         FROM non_published_news
#                         WHERE id IN ({placeholders})""",
#                     tuple(selected_ids)
#                 )
#                 articles = cursor.fetchall()

#                 if not articles:
#                     flash('No articles found for the selected IDs.', 'warning')
#                     cursor.close()
#                     return redirect(url_for('main.all_non_published_news'))

#                 # 2. Ensure PDF folder exists
#                 pdf_folder = current_app.config.get(
#                     'PDF_FOLDER',
#                     os.path.join(current_app.root_path, 'static', 'pdfs')
#                 )
#                 os.makedirs(pdf_folder, exist_ok=True)

#                 pdf_paths   = []
#                 pub_ids     = []

#                 for art in articles:
#                     # 3a. Insert into published_news
#                     cursor.execute(
#                         """INSERT INTO published_news
#                            (source_id, news_date, news_type, news_headline,
#                             news_text, news_url, keywords, date_of_insert)
#                            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
#                         (art['id'], art['news_date'], art['news_type'],
#                          art['news_headline'], art['news_text'],
#                          art['news_url'], art['keywords'], art['date_of_insert'])
#                     )
#                     db.commit()
#                     pub_id = cursor.lastrowid
#                     pub_ids.append(pub_id)

#                     # 3b. Generate PDF
#                     safe_name = f"news_{pub_id}.pdf"
#                     pdf_path  = os.path.join(pdf_folder, safe_name)
#                     pdf_ok    = False

#                     if art.get('news_url'):
#                         pdf_ok = generate_pdf_from_url(art['news_url'], pdf_path)

#                     if pdf_ok:
#                         cursor.execute(
#                             "UPDATE published_news SET pdf_path=%s WHERE id=%s",
#                             (safe_name, pub_id)
#                         )
#                         db.commit()
#                         pdf_paths.append(pdf_path)
#                     else:
#                         pdf_paths.append(None)

#                 # 4. Remove from non_published_news
#                 cursor.execute(
#                     f"DELETE FROM non_published_news WHERE id IN ({placeholders})",
#                     tuple(selected_ids)
#                 )
#                 db.commit()

#                 # 5. Send email
#                 try:
#                     date_label = datetime.now().strftime('%d %B %Y')
#                     send_news_email(articles, [p for p in pdf_paths if p], date_label)
#                     # Mark email sent
#                     for pub_id in pub_ids:
#                         cursor.execute(
#                             "UPDATE published_news SET email_sent=1, email_sent_at=NOW() WHERE id=%s",
#                             (pub_id,)
#                         )
#                     db.commit()
#                     flash(f'{len(articles)} article(s) published, PDFs generated, and email sent successfully.', 'success')
#                 except Exception as mail_err:
#                     flash(f'{len(articles)} article(s) published and PDFs generated. Email failed: {str(mail_err)}', 'warning')

#         except Exception as e:
#             db.rollback()
#             flash(f'Error: {str(e)}', 'danger')
#             traceback.print_exc()

#         cursor.close()
#         return redirect(url_for('main.all_non_published_news'))

#     # GET
#     try:
#         cursor.execute("""
#             SELECT id, news_date, news_type, news_headline,
#                    news_text, news_url, keywords, date_of_insert
#             FROM non_published_news
#             WHERE published = 0
#             ORDER BY date_of_insert DESC
#         """)
#         news = cursor.fetchall()
#     except Exception as e:
#         flash(f'Error loading news: {str(e)}', 'danger')
#         news = []
#     finally:
#         cursor.close()

#     return render_template('main/all_non_published_news.html', news=news)


# # ================================================================
# #  ROUTE: Today's Published News
# # ================================================================
# @main_bp.route('/today-published-news')
# @login_required
# def today_published_news():
#     db     = get_db()
#     cursor = db.cursor(dictionary=True)
#     today  = date.today()
#     news   = []

#     try:
#         cursor.execute("""
#             SELECT id, news_date, news_type, news_headline,
#                    news_url, pdf_path, published_at
#             FROM published_news
#             WHERE DATE(published_at) = %s
#             ORDER BY published_at DESC
#         """, (today,))
#         news = cursor.fetchall()
#     except Exception as e:
#         flash(f'Error loading published news: {str(e)}', 'danger')
#     finally:
#         cursor.close()

#     return render_template('main/today_published_news.html', news=news, today=today)


# # ================================================================
# #  ROUTE: Download PDF
# # ================================================================
# @main_bp.route('/download-pdf/<int:news_id>')
# @login_required
# def download_pdf(news_id):
#     db     = get_db()
#     cursor = db.cursor(dictionary=True)

#     try:
#         cursor.execute("SELECT pdf_path FROM published_news WHERE id=%s", (news_id,))
#         row = cursor.fetchone()
#     finally:
#         cursor.close()

#     if not row or not row['pdf_path']:
#         flash('PDF not found.', 'danger')
#         return redirect(url_for('main.today_published_news'))

#     pdf_folder = current_app.config.get(
#         'PDF_FOLDER',
#         os.path.join(current_app.root_path, 'static', 'pdfs')
#     )
#     return send_from_directory(pdf_folder, row['pdf_path'], as_attachment=True)


# # ================================================================
# #  ROUTE: Manual re-send email for today
# # ================================================================
# @main_bp.route('/send-email-today')
# @login_required
# def send_email_today():
#     db     = get_db()
#     cursor = db.cursor(dictionary=True)
#     today  = date.today()

#     try:
#         cursor.execute("""
#             SELECT id, news_date, news_type, news_headline, news_url, pdf_path
#             FROM published_news
#             WHERE DATE(published_at) = %s
#             ORDER BY published_at DESC
#         """, (today,))
#         articles = cursor.fetchall()

#         if not articles:
#             flash('No published news for today to send.', 'warning')
#             cursor.close()
#             return redirect(url_for('main.today_published_news'))

#         pdf_folder = current_app.config.get(
#             'PDF_FOLDER',
#             os.path.join(current_app.root_path, 'static', 'pdfs')
#         )
#         pdf_paths = [
#             os.path.join(pdf_folder, a['pdf_path'])
#             for a in articles if a.get('pdf_path')
#         ]

#         date_label = today.strftime('%d %B %Y')
#         send_news_email(articles, pdf_paths, date_label)
#         flash('Email sent successfully to niyati.b@seamlessautomations.com.', 'success')

#     except Exception as e:
#         flash(f'Failed to send email: {str(e)}', 'danger')
#         traceback.print_exc()
#     finally:
#         cursor.close()

#     return redirect(url_for('main.today_published_news'))


# @main_bp.route('/user-settings', methods=['GET', 'POST'])
# @login_required
# def user_settings():
#     db     = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == 'POST':
#         run_frequency        = request.form.get('run_frequency', '1')
#         custom_frequency     = request.form.get('custom_frequency') or None
#         scraper_enabled      = 1 if request.form.get('scraper_enabled') else 0
#         publish_mode         = request.form.get('publish_mode', 'manual')
#         content_categories   = ','.join(request.form.getlist('content_categories')) or 'all'
#         email_recipient      = request.form.get('email_recipient', '').strip()
#         email_cc             = request.form.get('email_cc', '').strip()
#         email_subject_prefix = request.form.get('email_subject_prefix', 'Daily News Alert').strip()
#         email_on_publish     = 1 if request.form.get('email_on_publish') else 0

#         try:
#             # Upsert — update row 1 (single global settings)
#             cursor.execute("""
#                 INSERT INTO user_settings
#                     (id, run_frequency, custom_frequency, scraper_enabled,
#                      publish_mode, content_categories, email_recipient,
#                      email_cc, email_subject_prefix, email_on_publish)
#                 VALUES (1, %s, %s, %s, %s, %s, %s, %s, %s, %s)
#                 ON DUPLICATE KEY UPDATE
#                     run_frequency        = VALUES(run_frequency),
#                     custom_frequency     = VALUES(custom_frequency),
#                     scraper_enabled      = VALUES(scraper_enabled),
#                     publish_mode         = VALUES(publish_mode),
#                     content_categories   = VALUES(content_categories),
#                     email_recipient      = VALUES(email_recipient),
#                     email_cc             = VALUES(email_cc),
#                     email_subject_prefix = VALUES(email_subject_prefix),
#                     email_on_publish     = VALUES(email_on_publish)
#             """, (run_frequency, custom_frequency, scraper_enabled,
#                   publish_mode, content_categories, email_recipient,
#                   email_cc, email_subject_prefix, email_on_publish))
#             db.commit()
#             flash('Settings saved successfully.', 'success')
#         except Exception as e:
#             db.rollback()
#             flash(f'Error saving settings: {str(e)}', 'danger')
#         finally:
#             cursor.close()

#         return redirect(url_for('main.user_settings'))

#     # GET — load existing settings
#     try:
#         cursor.execute("SELECT * FROM user_settings WHERE id = 1")
#         settings = cursor.fetchone() or {}
#     except Exception:
#         settings = {}
#     finally:
#         cursor.close()

#     return render_template('main/user_settings.html', settings=settings)


# # ================================================================
# #  Helper — get settings (call this anywhere you need them)
# # ================================================================
# def get_settings():
#     """Returns the current user_settings row as a dict."""
#     db     = get_db()
#     cursor = db.cursor(dictionary=True)
#     try:
#         cursor.execute("SELECT * FROM user_settings WHERE id = 1")
#         row = cursor.fetchone()
#         return row or {}
#     except Exception:
#         return {}
#     finally:
#         cursor.close()


# # ================================================================
# #  Updated all_non_published_news — respects content_categories
# #  and publish_mode from settings
# # ================================================================
# # In your existing all_non_published_news GET section, replace the
# # cursor.execute query with this:

# #   settings = get_settings()
# #   categories = (settings.get('content_categories') or 'all').split(',')
# #
# #   if 'all' in categories:
# #       cursor.execute("""
# #           SELECT id, news_date, news_type, news_headline,
# #                  news_text, news_url, keywords, date_of_insert
# #           FROM non_published_news WHERE published = 0
# #           ORDER BY date_of_insert DESC
# #       """)
# #   else:
# #       placeholders = ','.join(['%s'] * len(categories))
# #       cursor.execute(f"""
# #           SELECT id, news_date, news_type, news_headline,
# #                  news_text, news_url, keywords, date_of_insert
# #           FROM non_published_news
# #           WHERE published = 0
# #             AND LOWER(news_type) IN ({placeholders})
# #           ORDER BY date_of_insert DESC
# #       """, tuple(c.lower() for c in categories))


# # ================================================================
# #  NAVBAR snippet — add Settings link to base.html navbar
# #  Find the nav-right-links div in your base.html and add:
# # ================================================================

# # <a href="{{ url_for('main.user_settings') }}"
# #    class="nav-main-btn {{ 'active' if request.endpoint == 'main.user_settings' else '' }}"
# #    style="text-decoration:none;">
# #   ⚙️ Settings
# # </a>


from .auth import login_required
from app.db import get_db
import smtplib
import os
import traceback
from datetime import date, datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

from flask import Blueprint, render_template, request, redirect, url_for, flash, \
    send_from_directory, current_app
from .auth import login_required
from app.db import get_db


main_bp = Blueprint('main', __name__)


@main_bp.route('/')
def index():
    return render_template('main/landing.html')


@main_bp.route('/home')
@login_required
def home():
    from datetime import date
    db = get_db()
    cursor = db.cursor(dictionary=True)

    today = date.today()
    today_published_count = 0
    today_unpublished_count = 0

    try:
        cursor.execute(
            "SELECT COUNT(*) as cnt FROM news_articles WHERE published = 1 AND DATE(created_at) = %s",
            (today,)
        )
        today_published_count = cursor.fetchone()['cnt']

        cursor.execute(
            "SELECT COUNT(*) as cnt FROM news_articles WHERE published = 0 AND DATE(created_at) = %s",
            (today,)
        )
        today_unpublished_count = cursor.fetchone()['cnt']
    except Exception as e:
        print(f"Error loading dashboard counts: {e}")
    finally:
        cursor.close()

    return render_template(
        'main/home.html',
        today_published_count=today_published_count,
        today_unpublished_count=today_unpublished_count
    )


@main_bp.route('/view-keywords', methods=['GET', 'POST'])
@login_required
def view_keywords():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        action = request.form.get('action')

        # ADD KEYWORD
        if action == 'add':
            sr_no = request.form.get('sr_no', '').strip()
            keyword = request.form.get('keyword', '').strip()

            if not sr_no or not keyword:
                flash('Both Sr. No and Keyword are required.', 'danger')
                cursor.close()
                return redirect(url_for('main.view_keywords'))

            try:
                sr_no = int(sr_no)

                cursor.execute("SELECT id FROM keywords WHERE sr_no = %s", (sr_no,))
                existing_sr = cursor.fetchone()

                if existing_sr:
                    flash('Sr. No already exists.', 'danger')
                else:
                    cursor.execute(
                        "INSERT INTO keywords (sr_no, keyword) VALUES (%s, %s)",
                        (sr_no, keyword)
                    )
                    db.commit()
                    flash('Keyword added successfully.', 'success')

            except ValueError:
                flash('Sr. No must be a valid number.', 'danger')

            except Exception as e:
                db.rollback()
                flash(f'Error while adding keyword: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_keywords'))

        # EDIT KEYWORD
        elif action == 'edit':
            keyword_id = request.form.get('keyword_id', '').strip()
            keyword = request.form.get('edit_keyword', '').strip()

            if not keyword_id or not keyword:
                flash('Keyword ID and Keyword are required.', 'danger')
                cursor.close()
                return redirect(url_for('main.view_keywords'))

            try:
                cursor.execute(
                    "UPDATE keywords SET keyword = %s WHERE id = %s",
                    (keyword, keyword_id)
                )
                db.commit()

                if cursor.rowcount > 0:
                    flash('Keyword updated successfully.', 'success')
                else:
                    flash('Keyword not found.', 'warning')

            except Exception as e:
                db.rollback()
                flash(f'Error while updating keyword: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_keywords'))

        # BULK DELETE
        elif action == 'bulk_delete':
            selected_ids = request.form.getlist('selected_keywords')

            if not selected_ids:
                flash('Please select at least one row to delete.', 'warning')
                cursor.close()
                return redirect(url_for('main.view_keywords'))

            try:
                placeholders = ','.join(['%s'] * len(selected_ids))
                query = f"DELETE FROM keywords WHERE id IN ({placeholders})"
                cursor.execute(query, tuple(selected_ids))
                db.commit()
                flash('Selected keywords deleted successfully.', 'success')

            except Exception as e:
                db.rollback()
                flash(f'Error while deleting keywords: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_keywords'))

    cursor.execute("SELECT id, sr_no, keyword FROM keywords ORDER BY sr_no ASC")
    keywords = cursor.fetchall()
    cursor.close()

    return render_template('main/view_keywords.html', keywords=keywords)


@main_bp.route('/view-websites', methods=['GET', 'POST'])
@login_required
def view_websites():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        action = request.form.get('action')

        # ADD WEBSITE
        if action == 'add':
            sr_no = request.form.get('sr_no', '').strip()
            website = request.form.get('websites', '').strip()

            if not sr_no or not website:
                flash('Both Sr. No and website are required.', 'danger')
                cursor.close()
                return redirect(url_for('main.view_websites'))

            try:
                sr_no = int(sr_no)

                cursor.execute("SELECT id FROM websites WHERE sr_no = %s", (sr_no,))
                existing_sr = cursor.fetchone()

                if existing_sr:
                    flash('Sr. No already exists.', 'danger')
                else:
                    cursor.execute(
                        "INSERT INTO websites (sr_no, websites) VALUES (%s, %s)",
                        (sr_no, website)
                    )
                    db.commit()
                    flash('Website added successfully.', 'success')

            except ValueError:
                flash('Sr. No must be a valid number.', 'danger')

            except Exception as e:
                db.rollback()
                flash(f'Error while adding website: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_websites'))

        # EDIT WEBSITE
        elif action == 'edit':
            websites_id = request.form.get('websites_id', '').strip()
            website = request.form.get('edit_websites', '').strip()

            if not websites_id or not website:
                flash('Website ID and website are required.', 'danger')
                cursor.close()
                return redirect(url_for('main.view_websites'))

            try:
                cursor.execute(
                    "UPDATE websites SET websites = %s WHERE id = %s",
                    (website, websites_id)
                )
                db.commit()

                if cursor.rowcount > 0:
                    flash('Website updated successfully.', 'success')
                else:
                    flash('Website not found.', 'warning')

            except Exception as e:
                db.rollback()
                flash(f'Error while updating website: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_websites'))

        # BULK DELETE
        elif action == 'bulk_delete':
            selected_ids = request.form.getlist('selected_websites')

            if not selected_ids:
                flash('Please select at least one row to delete.', 'warning')
                cursor.close()
                return redirect(url_for('main.view_websites'))

            try:
                placeholders = ','.join(['%s'] * len(selected_ids))
                query = f"DELETE FROM websites WHERE id IN ({placeholders})"
                cursor.execute(query, tuple(selected_ids))
                db.commit()
                flash('Selected websites deleted successfully.', 'success')

            except Exception as e:
                db.rollback()
                flash(f'Error while deleting websites: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_websites'))

    cursor.execute("SELECT id, sr_no, websites FROM websites ORDER BY sr_no ASC")
    websites = cursor.fetchall()
    cursor.close()

    return render_template('main/view_websites.html', websites=websites)


@main_bp.route('/view-news-type', methods=['GET', 'POST'])
@login_required
def view_news_type():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'add':
            sr_no = request.form.get('sr_no', '').strip()
            news_type = request.form.get('news_type', '').strip()

            if not sr_no or not news_type:
                flash('Both Sr. No and News Type are required.', 'danger')
                cursor.close()
                return redirect(url_for('main.view_news_type'))

            try:
                sr_no = int(sr_no)
                cursor.execute("SELECT id FROM news WHERE sr_no = %s", (sr_no,))
                if cursor.fetchone():
                    flash('Sr. No already exists.', 'danger')
                else:
                    cursor.execute(
                        "INSERT INTO news (sr_no, news_type) VALUES (%s, %s)",
                        (sr_no, news_type)
                    )
                    db.commit()
                    flash('News type added successfully.', 'success')
            except ValueError:
                flash('Sr. No must be a valid number.', 'danger')
            except Exception as e:
                db.rollback()
                flash(f'Error while adding news type: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_news_type'))

        elif action == 'edit':
            news_type_id = request.form.get('news_type_id', '').strip()
            news_type = request.form.get('edit_news_type', '').strip()

            if not news_type_id or not news_type:
                flash('News Type ID and News Type are required.', 'danger')
                cursor.close()
                return redirect(url_for('main.view_news_type'))

            try:
                cursor.execute(
                    "UPDATE news SET news_type = %s WHERE id = %s",
                    (news_type, news_type_id)
                )
                db.commit()
                if cursor.rowcount > 0:
                    flash('News type updated successfully.', 'success')
                else:
                    flash('News type not found.', 'warning')
            except Exception as e:
                db.rollback()
                flash(f'Error while updating news type: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_news_type'))

        elif action == 'bulk_delete':
            selected_ids = request.form.getlist('selected_news_types')

            if not selected_ids:
                flash('Please select at least one row to delete.', 'warning')
                cursor.close()
                return redirect(url_for('main.view_news_type'))

            try:
                placeholders = ','.join(['%s'] * len(selected_ids))
                cursor.execute(f"DELETE FROM news WHERE id IN ({placeholders})", tuple(selected_ids))
                db.commit()
                flash('Selected news types deleted successfully.', 'success')
            except Exception as e:
                db.rollback()
                flash(f'Error while deleting news types: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_news_type'))

    cursor.execute("SELECT id, sr_no, news_type FROM news ORDER BY sr_no ASC")
    news_types = cursor.fetchall()
    cursor.close()
    return render_template('main/view_news_type.html', news_types=news_types)


@main_bp.route('/view-commodity', methods=['GET', 'POST'])
@login_required
def view_commodity():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'add':
            sr_no = request.form.get('sr_no', '').strip()
            commodity = request.form.get('commodity', '').strip()

            if not sr_no or not commodity:
                flash('Both Sr. No and Commodity are required.', 'danger')
                cursor.close()
                return redirect(url_for('main.view_commodity'))

            try:
                sr_no = int(sr_no)
                cursor.execute("SELECT id FROM commodity WHERE sr_no = %s", (sr_no,))
                if cursor.fetchone():
                    flash('Sr. No already exists.', 'danger')
                else:
                    cursor.execute(
                        "INSERT INTO commodity (sr_no, commodity) VALUES (%s, %s)",
                        (sr_no, commodity)
                    )
                    db.commit()
                    flash('Commodity added successfully.', 'success')
            except ValueError:
                flash('Sr. No must be a valid number.', 'danger')
            except Exception as e:
                db.rollback()
                flash(f'Error while adding commodity: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_commodity'))

        elif action == 'edit':
            commodity_id = request.form.get('commodity_id', '').strip()
            commodity = request.form.get('edit_commodity', '').strip()

            if not commodity_id or not commodity:
                flash('Commodity ID and Commodity are required.', 'danger')
                cursor.close()
                return redirect(url_for('main.view_commodity'))

            try:
                cursor.execute(
                    "UPDATE commodity SET commodity = %s WHERE id = %s",
                    (commodity, commodity_id)
                )
                db.commit()
                if cursor.rowcount > 0:
                    flash('Commodity updated successfully.', 'success')
                else:
                    flash('Commodity not found.', 'warning')
            except Exception as e:
                db.rollback()
                flash(f'Error while updating commodity: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_commodity'))

        elif action == 'bulk_delete':
            selected_ids = request.form.getlist('selected_commodities')

            if not selected_ids:
                flash('Please select at least one row to delete.', 'warning')
                cursor.close()
                return redirect(url_for('main.view_commodity'))

            try:
                placeholders = ','.join(['%s'] * len(selected_ids))
                cursor.execute(f"DELETE FROM commodity WHERE id IN ({placeholders})", tuple(selected_ids))
                db.commit()
                flash('Selected commodities deleted successfully.', 'success')
            except Exception as e:
                db.rollback()
                flash(f'Error while deleting commodities: {str(e)}', 'danger')

            cursor.close()
            return redirect(url_for('main.view_commodity'))

    cursor.execute("SELECT id, sr_no, commodity FROM commodity ORDER BY sr_no ASC")
    commodities = cursor.fetchall()
    cursor.close()
    return render_template('main/view_commodity.html', commodities=commodities)


def generate_pdf_from_url(url: str, output_path: str) -> bool:
    """
    Visits `url` with a headless Chromium browser, dismisses popups,
    and saves the rendered page as a PDF to `output_path`.
    Returns True on success, False on failure.
    """
    try:
        from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                accept_downloads=True,
                java_script_enabled=True,
            )
            page = context.new_page()

            page.on("dialog", lambda dialog: dialog.dismiss())

            try:
                page.goto(url, wait_until="networkidle", timeout=30000)
            except PWTimeout:
                page.goto(url, wait_until="domcontentloaded", timeout=20000)

            for selector in [
                "button[id*='accept']", "button[class*='accept']",
                "button[id*='close']", "button[class*='close']",
                "button[id*='agree']", "button[class*='agree']",
                "[aria-label*='close']", "[aria-label*='Close']",
                ".modal-close", ".popup-close", ".cookie-close",
            ]:
                try:
                    btn = page.locator(selector).first
                    if btn.is_visible(timeout=1500):
                        btn.click(timeout=1500)
                except Exception:
                    pass

            page.wait_for_timeout(1500)

            page.pdf(
                path=output_path,
                format="A4",
                margin={"top": "20mm", "bottom": "20mm", "left": "15mm", "right": "15mm"},
                print_background=True,
            )
            browser.close()
        return True

    except Exception as e:
        print(f"[PDF ERROR] {url} → {e}")
        traceback.print_exc()
        return False


def render_email_html(news_items: list, date_label: str) -> str:
    from jinja2 import Environment, FileSystemLoader
    template_dir = os.path.join(current_app.root_path, 'templates', 'main')
    env = Environment(loader=FileSystemLoader(template_dir))
    tmpl = env.get_template('email_template.html')
    return tmpl.render(news_items=news_items, date_label=date_label)


def send_news_email(news_items: list, pdf_paths: list, date_label: str):
    cfg = current_app.config
    to_addr = "niyati.b@seamlessautomations.com"

    msg = MIMEMultipart('mixed')
    msg['Subject'] = f"Daily News Alert — {date_label}"
    msg['From'] = cfg.get('MAIL_FROM', cfg.get('MAIL_USERNAME', ''))
    msg['To'] = to_addr

    html_body = render_email_html(news_items, date_label)
    msg.attach(MIMEText(html_body, 'html', 'utf-8'))

    for pdf_path in pdf_paths:
        if pdf_path and os.path.exists(pdf_path):
            with open(pdf_path, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
            encoders.encode_base64(part)
            filename = os.path.basename(pdf_path)
            part.add_header('Content-Disposition', f'attachment; filename="{filename}"')
            msg.attach(part)

    with smtplib.SMTP(cfg['MAIL_SERVER'], cfg['MAIL_PORT']) as server:
        server.ehlo()
        if cfg.get('MAIL_USE_TLS', True):
            server.starttls()
        server.login(cfg['MAIL_USERNAME'], cfg['MAIL_PASSWORD'])
        server.sendmail(msg['From'], [to_addr], msg.as_string())


def send_news_email_links(news_items: list, pub_ids: list, date_label: str, settings: dict):
    """
    Auto-publish mode: email contains links to hosted PDFs, not attachments.
    """
    cfg = current_app.config
    to_addr = settings.get('email_recipient', 'niyati.b@seamlessautomations.com')
    cc_raw = settings.get('email_cc', '') or ''
    cc_list = [e.strip() for e in cc_raw.split(',') if e.strip()]
    subject_prefix = settings.get('email_subject_prefix', 'Daily News Alert')

    base_url = current_app.config.get('BASE_URL', 'http://127.0.0.1:5000')
    items_with_links = []
    for art, pub_id in zip(news_items, pub_ids):
        item = dict(art)
        item['pdf_view_url'] = f"{base_url}/download-pdf/{pub_id}"
        items_with_links.append(item)

    msg = MIMEMultipart('mixed')
    msg['Subject'] = f"{subject_prefix} — {date_label}"
    msg['From'] = cfg.get('MAIL_FROM', cfg.get('MAIL_USERNAME', ''))
    msg['To'] = to_addr
    if cc_list:
        msg['Cc'] = ', '.join(cc_list)

    html_body = render_email_html(items_with_links, date_label)
    msg.attach(MIMEText(html_body, 'html', 'utf-8'))

    all_recipients = [to_addr] + cc_list
    with smtplib.SMTP(cfg['MAIL_SERVER'], cfg['MAIL_PORT']) as server:
        server.ehlo()
        if cfg.get('MAIL_USE_TLS', True):
            server.starttls()
        server.login(cfg['MAIL_USERNAME'], cfg['MAIL_PASSWORD'])
        server.sendmail(msg['From'], all_recipients, msg.as_string())


@main_bp.route('/all-non-published-news')
@login_required
def all_non_published_news():
    db = get_db()
    cursor = db.cursor(dictionary=True)
 
    try:
        cursor.execute("SELECT * FROM user_settings WHERE id = 1")
        settings = cursor.fetchone() or {}
    except Exception:
        settings = {}
 
    categories_str = settings.get('content_categories', 'all') or 'all'
    categories = [c.strip().lower() for c in categories_str.split(',') if c.strip()]
 
    try:
        if 'all' in categories:
            cursor.execute("""
                SELECT id, news_date, news_type, news_headline,
                       news_text, news_url, keywords, date_of_insert
                FROM non_published_news
                WHERE published = 0
                ORDER BY date_of_insert DESC
            """)
        else:
            placeholders_cat = ','.join(['%s'] * len(categories))
            cursor.execute(f"""
                SELECT id, news_date, news_type, news_headline,
                       news_text, news_url, keywords, date_of_insert
                FROM non_published_news
                WHERE published = 0
                  AND LOWER(news_type) IN ({placeholders_cat})
                ORDER BY date_of_insert DESC
            """, tuple(categories))
        news = cursor.fetchall()
    except Exception as e:
        flash(f'Error loading news: {str(e)}', 'danger')
        news = []
    finally:
        cursor.close()
 
    return render_template('main/all_non_published_news.html', news=news)
 
 
@main_bp.route('/all-non-published-news/actions', methods=['POST'])
@login_required
def all_non_published_news_actions():
    db = get_db()
    cursor = db.cursor(dictionary=True)
    action = request.form.get('action')
    selected_ids = request.form.getlist('selected_news')
 
    if not selected_ids:
        flash('Please select at least one article.', 'warning')
        cursor.close()
        return redirect(url_for('main.all_non_published_news'))
 
    placeholders = ','.join(['%s'] * len(selected_ids))
 
    try:
        if action == 'delete':
            cursor.execute(
                f"DELETE FROM non_published_news WHERE id IN ({placeholders})",
                tuple(selected_ids)
            )
            db.commit()
            flash(f'{cursor.rowcount} article(s) deleted successfully.', 'success')
 
        elif action == 'publish':
            cursor.execute(
                f"""SELECT id, news_date, news_type, news_headline,
                           news_text, news_url, keywords, date_of_insert
                    FROM non_published_news
                    WHERE id IN ({placeholders})""",
                tuple(selected_ids)
            )
            articles = cursor.fetchall()
 
            if not articles:
                flash('No articles found for the selected IDs.', 'warning')
                cursor.close()
                return redirect(url_for('main.all_non_published_news'))
 
            pdf_folder = current_app.config.get(
                'PDF_FOLDER',
                os.path.join(current_app.root_path, 'static', 'pdfs')
            )
            os.makedirs(pdf_folder, exist_ok=True)
 
            pdf_paths = []
            pub_ids = []
 
            for art in articles:
                cursor.execute(
                    """INSERT INTO published_news
                       (source_id, news_date, news_type, news_headline,
                        news_text, news_url, keywords, date_of_insert)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (
                        art['id'], art['news_date'], art['news_type'],
                        art['news_headline'], art['news_text'],
                        art['news_url'], art['keywords'], art['date_of_insert']
                    )
                )
                db.commit()
                pub_id = cursor.lastrowid
                pub_ids.append(pub_id)
 
                safe_name = f"news_{pub_id}.pdf"
                pdf_path = os.path.join(pdf_folder, safe_name)
                pdf_ok = False
 
                if art.get('news_url'):
                    pdf_ok = generate_pdf_from_url(art['news_url'], pdf_path)
 
                if pdf_ok:
                    cursor.execute(
                        "UPDATE published_news SET pdf_path=%s WHERE id=%s",
                        (safe_name, pub_id)
                    )
                    db.commit()
                    pdf_paths.append(pdf_path)
                else:
                    pdf_paths.append(None)
 
            cursor.execute(
                f"DELETE FROM non_published_news WHERE id IN ({placeholders})",
                tuple(selected_ids)
            )
            db.commit()
 
            try:
                cursor.execute("SELECT * FROM user_settings WHERE id = 1")
                settings = cursor.fetchone() or {}
            except Exception:
                settings = {}
 
            email_on_publish = settings.get('email_on_publish', 1)
            publish_mode = settings.get('publish_mode', 'manual')
 
            if email_on_publish:
                try:
                    date_label = datetime.now().strftime('%d %B %Y')
                    if publish_mode == 'auto':
                        send_news_email_links(articles, pub_ids, date_label, settings)
                    else:
                        send_news_email(articles, [p for p in pdf_paths if p], date_label)
 
                    for pub_id in pub_ids:
                        cursor.execute(
                            "UPDATE published_news SET email_sent=1, email_sent_at=NOW() WHERE id=%s",
                            (pub_id,)
                        )
                    db.commit()
                    flash(f'{len(articles)} article(s) published, PDFs generated, and email sent successfully.', 'success')
                except Exception as mail_err:
                    flash(f'{len(articles)} article(s) published and PDFs generated. Email failed: {str(mail_err)}', 'warning')
            else:
                flash(f'{len(articles)} article(s) published and PDFs generated successfully.', 'success')
 
    except Exception as e:
        db.rollback()
        flash(f'Error: {str(e)}', 'danger')
        traceback.print_exc()
 
    cursor.close()
    return redirect(url_for('main.all_non_published_news'))
 

@main_bp.route('/refresh-news', methods=['POST'])
@login_required
def refresh_news():
    try:
        from app.news_scraper import run_news_scraper
        result = run_news_scraper()
 
        if result.get('success'):
            flash(result.get('message', 'Refresh completed'), 'success')
        else:
            flash(result.get('message', 'Refresh failed'), 'danger')
    except Exception as e:
        flash(f'Refresh failed: {str(e)}', 'danger')
 
    return redirect(url_for('main.all_non_published_news'))
 
# def all_non_published_news():
#     db = get_db()
#     cursor = db.cursor(dictionary=True)

#     if request.method == 'POST':
#         action = request.form.get('action')
#         selected_ids = request.form.getlist('selected_news')

#         if not selected_ids:
#             flash('Please select at least one article.', 'warning')
#             cursor.close()
#             return redirect(url_for('main.all_non_published_news'))

#         placeholders = ','.join(['%s'] * len(selected_ids))

#         try:
#             # DELETE
#             if action == 'delete':
#                 cursor.execute(
#                     f"DELETE FROM non_published_news WHERE id IN ({placeholders})",
#                     tuple(selected_ids)
#                 )
#                 db.commit()
#                 flash(f'{cursor.rowcount} article(s) deleted successfully.', 'success')

#             # PUBLISH
#             elif action == 'publish':
#                 cursor.execute(
#                     f"""SELECT id, news_date, news_type, news_headline,
#                                news_text, news_url, keywords, date_of_insert
#                         FROM non_published_news
#                         WHERE id IN ({placeholders})""",
#                     tuple(selected_ids)
#                 )
#                 articles = cursor.fetchall()

#                 if not articles:
#                     flash('No articles found for the selected IDs.', 'warning')
#                     cursor.close()
#                     return redirect(url_for('main.all_non_published_news'))

#                 pdf_folder = current_app.config.get(
#                     'PDF_FOLDER',
#                     os.path.join(current_app.root_path, 'static', 'pdfs')
#                 )
#                 os.makedirs(pdf_folder, exist_ok=True)

#                 pdf_paths = []
#                 pub_ids = []

#                 for art in articles:
#                     cursor.execute(
#                         """INSERT INTO published_news
#                            (source_id, news_date, news_type, news_headline,
#                             news_text, news_url, keywords, date_of_insert)
#                            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
#                         (
#                             art['id'], art['news_date'], art['news_type'],
#                             art['news_headline'], art['news_text'],
#                             art['news_url'], art['keywords'], art['date_of_insert']
#                         )
#                     )
#                     db.commit()
#                     pub_id = cursor.lastrowid
#                     pub_ids.append(pub_id)

#                     safe_name = f"news_{pub_id}.pdf"
#                     pdf_path = os.path.join(pdf_folder, safe_name)
#                     pdf_ok = False

#                     if art.get('news_url'):
#                         pdf_ok = generate_pdf_from_url(art['news_url'], pdf_path)

#                     if pdf_ok:
#                         cursor.execute(
#                             "UPDATE published_news SET pdf_path=%s WHERE id=%s",
#                             (safe_name, pub_id)
#                         )
#                         db.commit()
#                         pdf_paths.append(pdf_path)
#                     else:
#                         pdf_paths.append(None)

#                 cursor.execute(
#                     f"DELETE FROM non_published_news WHERE id IN ({placeholders})",
#                     tuple(selected_ids)
#                 )
#                 db.commit()

#                 try:
#                     cursor.execute("SELECT * FROM user_settings WHERE id = 1")
#                     settings = cursor.fetchone() or {}
#                 except Exception:
#                     settings = {}

#                 email_on_publish = settings.get('email_on_publish', 1)
#                 publish_mode = settings.get('publish_mode', 'manual')

#                 if email_on_publish:
#                     try:
#                         date_label = datetime.now().strftime('%d %B %Y')
#                         if publish_mode == 'auto':
#                             send_news_email_links(articles, pub_ids, date_label, settings)
#                         else:
#                             send_news_email(articles, [p for p in pdf_paths if p], date_label)

#                         for pub_id in pub_ids:
#                             cursor.execute(
#                                 "UPDATE published_news SET email_sent=1, email_sent_at=NOW() WHERE id=%s",
#                                 (pub_id,)
#                             )
#                         db.commit()
#                         flash(f'{len(articles)} article(s) published, PDFs generated, and email sent successfully.', 'success')
#                     except Exception as mail_err:
#                         flash(f'{len(articles)} article(s) published and PDFs generated. Email failed: {str(mail_err)}', 'warning')
#                 else:
#                     flash(f'{len(articles)} article(s) published and PDFs generated successfully.', 'success')

#         except Exception as e:
#             db.rollback()
#             flash(f'Error: {str(e)}', 'danger')
#             traceback.print_exc()

#         cursor.close()
#         return redirect(url_for('main.all_non_published_news'))

#     # GET
#     try:
#         cursor.execute("SELECT * FROM user_settings WHERE id = 1")
#         settings = cursor.fetchone() or {}
#     except Exception:
#         settings = {}

#     categories_str = settings.get('content_categories', 'all') or 'all'
#     categories = [c.strip().lower() for c in categories_str.split(',') if c.strip()]

#     try:
#         if 'all' in categories:
#             cursor.execute("""
#                 SELECT id, news_date, news_type, news_headline,
#                        news_text, news_url, keywords, date_of_insert
#                 FROM non_published_news
#                 WHERE published = 0
#                 ORDER BY date_of_insert DESC
#             """)
#         else:
#             placeholders_cat = ','.join(['%s'] * len(categories))
#             cursor.execute(f"""
#                 SELECT id, news_date, news_type, news_headline,
#                        news_text, news_url, keywords, date_of_insert
#                 FROM non_published_news
#                 WHERE published = 0
#                   AND LOWER(news_type) IN ({placeholders_cat})
#                 ORDER BY date_of_insert DESC
#             """, tuple(categories))
#         news = cursor.fetchall()
#     except Exception as e:
#         flash(f'Error loading news: {str(e)}', 'danger')
#         news = []
#     finally:
#         cursor.close()

#     return render_template('main/all_non_published_news.html', news=news)



@main_bp.route('/today-published-news')
@login_required
def today_published_news():
    db = get_db()
    cursor = db.cursor(dictionary=True)
    today = date.today()
    news = []

    try:
        cursor.execute("""
            SELECT id, news_date, news_type, news_headline,
                   news_url, pdf_path, published_at
            FROM published_news
            WHERE DATE(published_at) = %s
            ORDER BY published_at DESC
        """, (today,))
        news = cursor.fetchall()
    except Exception as e:
        flash(f'Error loading published news: {str(e)}', 'danger')
    finally:
        cursor.close()

    return render_template('main/today_published_news.html', news=news, today=today)


@main_bp.route('/download-pdf/<int:news_id>')
@login_required
def download_pdf(news_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    try:
        cursor.execute("SELECT pdf_path FROM published_news WHERE id=%s", (news_id,))
        row = cursor.fetchone()
    finally:
        cursor.close()

    if not row or not row['pdf_path']:
        flash('PDF not found.', 'danger')
        return redirect(url_for('main.today_published_news'))

    pdf_folder = current_app.config.get(
        'PDF_FOLDER',
        os.path.join(current_app.root_path, 'static', 'pdfs')
    )
    return send_from_directory(pdf_folder, row['pdf_path'], as_attachment=True)


@main_bp.route('/send-email-today')
@login_required
def send_email_today():
    db = get_db()
    cursor = db.cursor(dictionary=True)
    today = date.today()

    try:
        cursor.execute("""
            SELECT id, news_date, news_type, news_headline, news_url, pdf_path
            FROM published_news
            WHERE DATE(published_at) = %s
            ORDER BY published_at DESC
        """, (today,))
        articles = cursor.fetchall()

        if not articles:
            flash('No published news for today to send.', 'warning')
            cursor.close()
            return redirect(url_for('main.today_published_news'))

        pdf_folder = current_app.config.get(
            'PDF_FOLDER',
            os.path.join(current_app.root_path, 'static', 'pdfs')
        )
        pdf_paths = [
            os.path.join(pdf_folder, a['pdf_path'])
            for a in articles if a.get('pdf_path')
        ]

        date_label = today.strftime('%d %B %Y')
        send_news_email(articles, pdf_paths, date_label)
        flash('Email sent successfully to niyati.b@seamlessautomations.com.', 'success')

    except Exception as e:
        flash(f'Failed to send email: {str(e)}', 'danger')
        traceback.print_exc()
    finally:
        cursor.close()

    return redirect(url_for('main.today_published_news'))


@main_bp.route('/user-settings', methods=['GET', 'POST'])
@login_required
def user_settings():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        run_frequency = request.form.get('run_frequency', '1')
        custom_frequency = request.form.get('custom_frequency') or None
        scraper_enabled = 1 if request.form.get('scraper_enabled') else 0
        publish_mode = request.form.get('publish_mode', 'manual')
        content_categories = ','.join(request.form.getlist('content_categories')) or 'all'
        email_recipient = request.form.get('email_recipient', '').strip()
        email_cc = request.form.get('email_cc', '').strip()
        email_subject_prefix = request.form.get('email_subject_prefix', 'Daily News Alert').strip()
        email_on_publish = 1 if request.form.get('email_on_publish') else 0

        try:
            cursor.execute("""
                INSERT INTO user_settings
                    (id, run_frequency, custom_frequency, scraper_enabled,
                     publish_mode, content_categories, email_recipient,
                     email_cc, email_subject_prefix, email_on_publish)
                VALUES (1, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    run_frequency        = VALUES(run_frequency),
                    custom_frequency     = VALUES(custom_frequency),
                    scraper_enabled      = VALUES(scraper_enabled),
                    publish_mode         = VALUES(publish_mode),
                    content_categories   = VALUES(content_categories),
                    email_recipient      = VALUES(email_recipient),
                    email_cc             = VALUES(email_cc),
                    email_subject_prefix = VALUES(email_subject_prefix),
                    email_on_publish     = VALUES(email_on_publish)
            """, (
                run_frequency, custom_frequency, scraper_enabled,
                publish_mode, content_categories, email_recipient,
                email_cc, email_subject_prefix, email_on_publish
            ))
            db.commit()
            flash('Settings saved successfully.', 'success')
        except Exception as e:
            db.rollback()
            flash(f'Error saving settings: {str(e)}', 'danger')
        finally:
            cursor.close()

        return redirect(url_for('main.user_settings'))

    try:
        cursor.execute("SELECT * FROM user_settings WHERE id = 1")
        settings = cursor.fetchone() or {}
    except Exception:
        settings = {}
    finally:
        cursor.close()

    return render_template('main/user_settings.html', settings=settings)


def get_settings():
    """Returns the current user_settings row as a dict."""
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM user_settings WHERE id = 1")
        row = cursor.fetchone()
        return row or {}
    except Exception:
        return {}
    finally:
        cursor.close()