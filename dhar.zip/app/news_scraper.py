import json
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from urllib.parse import urljoin, urlparse
 
import mysql.connector
import requests
from bs4 import BeautifulSoup
from flask import current_app
 
from app.db import get_db
 
 
HEADERS = {
    "User-Agent": "Mozilla/5.0"
}
 
 
def clean_text(text):
    return re.sub(r"\s+", " ", text or "").strip()
 
 
def fetch_single_column(table_name, column_name):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute(f"SELECT {column_name} FROM {table_name} ORDER BY sr_no ASC")
    rows = cursor.fetchall()
    cursor.close()
 
    values = []
    for row in rows:
        raw = clean_text(row.get(column_name))
        if not raw:
            continue
 
        # Supports comma-separated values in one row
        parts = [x.strip() for x in raw.split(",") if x.strip()]
        values.extend(parts)
 
    # Remove duplicates while keeping order
    return list(dict.fromkeys(values))
 
 
def get_keywords():
    return fetch_single_column("keywords", "keyword")
 
 
def get_commodities():
    return fetch_single_column("commodity", "commodity")
 
 
def get_news_types():
    return fetch_single_column("news", "news_type")
 
 
def get_website_configs():
    """
    Reads JSON configs from websites.websites
 
    Example row value:
    {
      "name": "NDTV Latest",
      "url": "https://www.ndtv.com/latest",
      "listing_selector": "a[href]",
      "article_selectors": ["div.ins_storybody p", "article p"],
      "news_type": "general"
    }
    """
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT websites FROM websites ORDER BY sr_no ASC")
    rows = cursor.fetchall()
    cursor.close()
 
    configs = []
 
    for row in rows:
        raw = clean_text(row.get("websites"))
        if not raw:
            continue
 
        obj = None
        try:
            obj = json.loads(raw)
        except Exception:
            if raw.lower().startswith(("http://", "https://")):
                obj = {
                    "name": urlparse(raw).netloc or raw,
                    "url": raw,
                    "listing_selector": "a[href]",
                    "article_selectors": ["p"],
                    "news_type": "general"
                }
                print(f"Using fallback website config for URL: {raw}")
            else:
                print(f"Invalid website JSON skipped: {raw}")
                continue
 
        url = clean_text(obj.get("url"))
        listing_selector = clean_text(obj.get("listing_selector"))
        article_selectors = obj.get("article_selectors", [])
        name = clean_text(obj.get("name")) or urlparse(url).netloc
        news_type = clean_text(obj.get("news_type")) or "general"
 
        if not url:
            print(f"Skipped config without url: {raw}")
            continue
 
        if not listing_selector:
            print(f"Skipped config without listing_selector: {raw}")
            continue
 
        if not isinstance(article_selectors, list) or not article_selectors:
            print(f"Skipped config without article_selectors: {raw}")
            continue
 
        configs.append({
            "name": name,
            "url": url,
            "listing_selector": listing_selector,
            "article_selectors": article_selectors,
            "news_type": news_type
        })
 
    return configs
 
 
def create_db_config():
    cfg = current_app.config
    return {
        "host": cfg["MYSQL_HOST"],
        "user": cfg["MYSQL_USER"],
        "password": cfg["MYSQL_PASSWORD"],
        "database": cfg["MYSQL_DB"],
    }
 
 
def insert_article_threaded(headline, news_text, news_url, news_type, matched_terms, db_config):
    if not headline or not news_url:
        return False, "missing headline/url"
 
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
 
    cursor.execute(
        "SELECT id FROM non_published_news WHERE news_url = %s LIMIT 1",
        (news_url,)
    )
    if cursor.fetchone():
        cursor.close()
        conn.close()
        return False, "duplicate"
 
    cursor.execute(
        """
        INSERT INTO non_published_news
        (
            news_date,
            news_type,
            news_headline,
            news_text,
            news_url,
            keywords,
            published
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """,
        (
            date.today(),
            news_type,
            headline,
            news_text,
            news_url,
            ", ".join(matched_terms),
            0
        )
    )
    conn.commit()
    cursor.close()
    conn.close()
    return True, "inserted"
 
 
def process_article_task(article, site, keywords, commodities, news_types, db_config):
    headline = clean_text(article.get("headline"))
    news_url = clean_text(article.get("url"))
 
    if not headline or not news_url:
        return False, "missing headline/url"
 
    news_text = extract_article_text(news_url, site["article_selectors"])
    full_text = f"{headline} {news_text}"
 
    matched_keywords = find_matches(full_text, keywords)
    matched_commodities = find_matches(full_text, commodities)
 
    if not matched_keywords and not matched_commodities:
        return False, "no match"
 
    matched_terms = list(dict.fromkeys(matched_keywords + matched_commodities))
 
    news_type = choose_news_type(
        full_text=full_text,
        db_news_types=news_types,
        matched_commodities=matched_commodities,
        site_default_type=site.get("news_type", "general")
    )
 
    return insert_article_threaded(
        headline=headline,
        news_text=news_text,
        news_url=news_url,
        news_type=news_type,
        matched_terms=matched_terms,
        db_config=db_config
    )
 
 
def save_raw_json(site_name, articles):
    folder = os.path.join(current_app.instance_path, "downloaded_json")
    os.makedirs(folder, exist_ok=True)
 
    safe_name = re.sub(r"[^a-zA-Z0-9_-]+", "_", site_name)
    file_path = os.path.join(folder, f"{safe_name}.json")
 
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(articles, f, ensure_ascii=False, indent=2)
 
    return file_path
 
 
def fetch_html(url):
    response = requests.get(url, headers=HEADERS, timeout=20)
    response.raise_for_status()
    return response.text
 
 
def find_matches(text, values):
    text = (text or "").lower()
    matched = []
 
    for value in values:
        value_clean = value.strip()
        if not value_clean:
            continue
 
        pattern = rf"\b{re.escape(value_clean.lower())}\b"
        if re.search(pattern, text):
            matched.append(value_clean)
 
    return matched
 
 
def choose_news_type(full_text, db_news_types, matched_commodities, site_default_type):
    if matched_commodities:
        return "commodity"
 
    matches = find_matches(full_text, db_news_types)
    if matches:
        return matches[0]
 
    return site_default_type or "general"
 
 
def article_exists(news_url):
    db = get_db()
    cursor = db.cursor()
    cursor.execute(
        "SELECT id FROM non_published_news WHERE news_url = %s LIMIT 1",
        (news_url,)
    )
    row = cursor.fetchone()
    cursor.close()
    return row is not None
 
 
def insert_article(headline, news_text, news_url, news_type, matched_terms):
    if not headline or not news_url:
        return False, "missing headline/url"
 
    if article_exists(news_url):
        return False, "duplicate"
 
    db = get_db()
    cursor = db.cursor()
 
    cursor.execute(
        """
        INSERT INTO non_published_news
        (
            news_date,
            news_type,
            news_headline,
            news_text,
            news_url,
            keywords,
            published
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """,
        (
            date.today(),
            news_type,
            headline,
            news_text,
            news_url,
            ", ".join(matched_terms),
            0
        )
    )
 
    db.commit()
    cursor.close()
    return True, "inserted"
 
 
def scrape_listing(site_config):
    website_url = site_config["url"]
    listing_selector = site_config["listing_selector"]
 
    html = fetch_html(website_url)
    soup = BeautifulSoup(html, "html.parser")
 
    results = []
    seen_urls = set()
    website_host = urlparse(website_url).netloc.lower()
 
    for a in soup.select(listing_selector):
        headline = clean_text(a.get_text(" ", strip=True))
        href = clean_text(a.get("href"))
 
        if not headline or len(headline) < 25:
            continue
 
        if not href:
            continue
        if href.startswith("#"):
            continue
        if href.lower().startswith("javascript:"):
            continue
 
        full_url = urljoin(website_url, href)
        parsed = urlparse(full_url)
 
        if not parsed.scheme.startswith("http"):
            continue
 
        # keep same-site links only
        if website_host not in parsed.netloc.lower() and parsed.netloc.lower() not in website_host:
            continue
 
        if full_url in seen_urls:
            continue
 
        seen_urls.add(full_url)
 
        results.append({
            "headline": headline,
            "url": full_url
        })
 
    return results
 
 
def extract_article_text(article_url, article_selectors):
    try:
        html = fetch_html(article_url)
    except Exception as e:
        print(f"ARTICLE FETCH FAILED: {article_url} -> {e}")
        return ""
 
    soup = BeautifulSoup(html, "html.parser")
 
    for selector in article_selectors:
        paragraphs = soup.select(selector)
        if not paragraphs:
            continue
 
        parts = []
        for p in paragraphs:
            txt = clean_text(p.get_text(" ", strip=True))
            if txt and len(txt) > 30:
                parts.append(txt)
 
        if parts:
            unique_parts = []
            seen = set()
 
            for part in parts:
                if part not in seen:
                    seen.add(part)
                    unique_parts.append(part)
 
            return "\n".join(unique_parts).strip()
 
    return ""
 
 
def run_news_scraper():
    keywords = get_keywords()
    commodities = get_commodities()
    news_types = get_news_types()
    website_configs = get_website_configs()
    db_config = create_db_config()
 
    if not website_configs:
        return {
            "success": False,
            "inserted": 0,
            "skipped": 0,
            "failed_websites": 0,
            "total_extracted": 0,
            "message": "No valid website configs found in websites table."
        }
 
    total_extracted = 0
    inserted = 0
    skipped_articles = 0
    failed_websites = 0
    saved_files = []
 
    for site in website_configs:
        try:
            articles = scrape_listing(site)
        except Exception as e:
            print(f"FAILED WEBSITE: {site.get('url')} -> {e}")
            failed_websites += 1
            continue
 
        total_extracted += len(articles)
 
        try:
            saved_files.append(save_raw_json(site.get("name", "site"), articles))
        except Exception as e:
            print(f"JSON SAVE FAILED: {site.get('url')} -> {e}")
 
        if not articles:
            continue
 
        max_workers = min(8, len(articles))
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_article = {
                executor.submit(
                    process_article_task,
                    article,
                    site,
                    keywords,
                    commodities,
                    news_types,
                    db_config
                ): article
                for article in articles
            }
 
            for future in as_completed(future_to_article):
                article = future_to_article[future]
                try:
                    ok, reason = future.result()
                    if ok:
                        inserted += 1
                        print(f"INSERTED: {article.get('headline')}")
                    else:
                        skipped_articles += 1
                        print(f"SKIPPED - {reason}: {article.get('headline')}")
                except Exception as e:
                    skipped_articles += 1
                    print(f"ARTICLE WORKER FAILED: {article.get('headline')} -> {e}")
 
    return {
        "success": True,
        "inserted": inserted,
        "skipped": skipped_articles,
        "failed_websites": failed_websites,
        "total_extracted": total_extracted,
        "files": saved_files,
        "message": (
            f"Scraper completed. "
            f"Extracted: {total_extracted}, "
            f"Inserted: {inserted}, "
            f"Skipped Articles: {skipped_articles}, "
            f"Failed Websites: {failed_websites}"
        )
    }